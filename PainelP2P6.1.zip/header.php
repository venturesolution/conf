<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php
session_start();
if ($_SESSION['usuario'] == false) {
  header("Location: index.php?msg=erro_login");
  exit();
}

$dadosUser = buscarUsuario($_SESSION['usuario']);
$id_sessao = $dadosUser["id"];
$nome = $dadosUser["nome"];
$nivel = $dadosUser["nivel"];
$usuario = $dadosUser["usuario"];
$senha = $dadosUser["senha"];
?>
<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
    <a class="sidebar-brand brand-logo" href="cad_app.php"><img src="assets/images/logo.png" alt="logo" /></a>
    <a class="sidebar-brand brand-logo-mini" href="cad_app.php"><img src="assets/images/favicon.png" alt="logo" /></a>
  </div>
  <ul class="nav">
    <li class="nav-item profile">
      <div class="profile-desc">
        <div class="profile-pic">
          <div class="count-indicator">
            <img class="img-xs rounded-circle " src="assets/images/faces/logo_p.png" alt="">
            <span class="count bg-success"></span>
          </div>
          <div class="profile-name">
            <h5 class="mb-0 font-weight-normal"><?php echo $nome; ?></h5>
            <span><?php echo $nivel == 1 ? "Admin" : "Usuário"; ?></span>
          </div>
        </div>
        <a href="#" id="profile-dropdown" data-toggle="dropdown"><i class="mdi mdi-dots-vertical"></i></a>
        <div class="dropdown-menu dropdown-menu-right sidebar-dropdown preview-list" aria-labelledby="profile-dropdown">
          <div class="dropdown-divider"></div>
          <a href="usuario.php" class="dropdown-item preview-item">
            <div class="preview-thumbnail">
              <div class="preview-icon bg-dark rounded-circle">
                <i class="mdi mdi-onepassword  text-info"></i>
              </div>
            </div>
            <div class="preview-item-content">
              <p class="preview-subject ellipsis mb-1 text-small">Mudar Senha</p>
            </div>
          </a>
          <div class="dropdown-divider"></div>
        </div>
      </div>
    </li>
    <li class="nav-item nav-category">
      <span class="nav-link">Navevação</span>
    </li>
    <!--           <li class="nav-item menu-items">
            <a class="nav-link" href="home.php">
              <span class="menu-icon">
                <i class="mdi mdi-speedometer"></i>
              </span>
              <span class="menu-title">Principal</span>
            </a>
          </li> -->
    <li class="nav-item menu-items">
      <a class="nav-link" href="cad_app.php">
        <span class="menu-icon">
          <i class="mdi mdi-server-network"></i>
        </span>
        <span class="menu-title">Aplicativo</span>
      </a>
    </li>
    <li class="nav-item menu-items">
      <a class="nav-link" href="banners.php">
        <span class="menu-icon">
          <i class="mdi mdi-playlist-play"></i>
        </span>
        <span class="menu-title">Banner's</span>
      </a>
    </li>
    <li class="nav-item menu-items">
      <a class="nav-link" href="img.php">
        <span class="menu-icon">
          <i class="mdi mdi-playlist-play"></i>
        </span>
        <span class="menu-title">Enviar Imagem</span>
      </a>
    </li>
    <?php if ($nivel == 1) { ?>
      <li class="nav-item menu-items">
        <a class="nav-link" href="usuarios.php">
          <span class="menu-icon">
            <i class="mdi mdi-account-outline"></i>
          </span>
          <span class="menu-title">Usuários</span>
        </a>
      </li>
    <?php } ?>
  </ul>
</nav>
<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <!-- partial:partials/_navbar.html -->
  <nav class="navbar p-0 fixed-top d-flex flex-row">
    <div class="navbar-brand-wrapper d-flex d-lg-none align-items-center justify-content-center">
      <a class="navbar-brand brand-logo-mini" href="cad_app.php"><img src="assets/images/favicon.png" alt="logo" /></a>
    </div>
    <div class="navbar-menu-wrapper flex-grow d-flex align-items-stretch">
      <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
        <span class="mdi mdi-menu"></span>
      </button>

      <ul class="navbar-nav navbar-nav-right">
        <!--               <li class="nav-item dropdown d-none d-lg-block">
                <a class="nav-link btn btn-success create-new-button" href="cad_servidores.php">+ Cadastrar DNS</a>
              </li>
              -->
        <li class="nav-item dropdown border-left">
        </li>

        <li class="nav-item dropdown border-left">
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link" id="profileDropdown" href="#" data-toggle="dropdown">
            <div class="navbar-profile">
              <img class="img-xs rounded-circle" src="assets/images/faces/logo_p.png" alt="">
              <p class="mb-0 d-none d-sm-block navbar-profile-name"><?php echo $nome; ?></p>
              <i class="mdi mdi-menu-down d-none d-sm-block"></i>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="profileDropdown">
            <div class="dropdown-divider"></div>
            <a class="dropdown-item preview-item" href="usuario.php">
              <div class="preview-thumbnail">
                <div class="preview-icon bg-dark rounded-circle">
                  <i class="mdi mdi-settings text-success"></i>
                </div>
              </div>
              <div class="preview-item-content">
                <p class="preview-subject mb-1">Meus Dados</p>
              </div>
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item preview-item" href="sair.php">
              <div class="preview-thumbnail">
                <div class="preview-icon bg-dark rounded-circle">
                  <i class="mdi mdi-logout text-danger"></i>
                </div>
              </div>
              <div class="preview-item-content">
                <p class="preview-subject mb-1">Sair</p>
              </div>
            </a>
            <div class="dropdown-divider"></div>
          </div>
        </li>
      </ul>
      <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
        <span class="mdi mdi-format-line-spacing"></span>
      </button>
    </div>
  </nav>