-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 18-Ago-2022 às 10:07
-- Versão do servidor: 10.3.36-MariaDB
-- versão do PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `gsite_painel`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `app`
--

CREATE TABLE `app` (
  `id` int(11) NOT NULL,
  `api_dominio` varchar(300) NOT NULL,
  `login_logo` varchar(300) NOT NULL,
  `sidebar_logo` varchar(300) NOT NULL,
  `bg` varchar(300) NOT NULL,
  `vod_bg` varchar(300) NOT NULL,
  `info_suporte` varchar(300) NOT NULL,
  `trans1` varchar(10) NOT NULL,
  `cor1` varchar(300) NOT NULL,
  `trans2` varchar(10) NOT NULL,
  `cor2` varchar(300) NOT NULL,
  `trans3` varchar(10) NOT NULL,
  `cor3` varchar(300) NOT NULL,
  `api_register` varchar(300) NOT NULL,
  `api_auth` varchar(300) NOT NULL,
  `api_email` varchar(300) NOT NULL,
  `api_psp` varchar(300) NOT NULL,
  `campo1` varchar(300) NOT NULL,
  `campo2` varchar(300) NOT NULL,
  `campo3` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `app`
--

INSERT INTO `app` (`id`, `api_dominio`, `login_logo`, `sidebar_logo`, `bg`, `vod_bg`, `info_suporte`, `trans1`, `cor1`, `trans2`, `cor2`, `trans3`, `cor3`, `api_register`, `api_auth`, `api_email`, `api_psp`, `campo1`, `campo2`, `campo3`) VALUES
(1, 'gsite.top', 'https://xcpainel.com.br/control/assets/images/logo_painel.png', 'https://xcpainel.com.br/control/assets/images/logo_painel.png', 'http://gsite.top/painel/assets/images/bg.jpg', 'http://gsite.top/painel/assets/images/bg.jpg', 'Fale com seu \\nRevendedor', 'CC', '#33169c', 'CC', '#ffab00', 'CC', '#112d9c', 'https://auth.p2.wtf/api/v2/register', 'https://auth.p2.wtf/api/v2/auth', '@p2.wtf2', 'psp.p2.wtf', 'AVISOS SERVIDOR:', 'NÃO ESQUEÇA DE RENOVAR SUA ASSINATURA', 'NOVIDADES:');

-- --------------------------------------------------------

--
-- Estrutura da tabela `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `imagem` varchar(600) NOT NULL,
  `link` int(11) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `banners`
--

INSERT INTO `banners` (`id`, `nome`, `imagem`, `link`, `status`) VALUES
(1, 'BANNER1', '', 0, 1),
(2, 'BANNER2', '', 0, 0),
(3, 'BANNER3', '', 0, 0),
(4, 'BANNER4', '', 0, 0),
(5, 'BANNER5', '', 0, 0),
(6, 'BANNER6', '', 0, 0),
(7, 'BANNER7', '', 0, 0),
(8, 'BANNER8', '', 0, 0),
(9, 'BANNER9', '', 0, 0),
(10, 'BANNER10', '', 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `vencimento` varchar(255) NOT NULL,
  `nivel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `usuario`, `senha`, `vencimento`, `nivel`) VALUES
(1, 'Administrador', 'admin', 'admin', '', 1),
(2, 'Usuario', 'user', 'user', '', 0);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `app`
--
ALTER TABLE `app`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `app`
--
ALTER TABLE `app`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
