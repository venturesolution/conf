<!DOCTYPE html>
<html lang="en">
<?php 
include_once "head.php";
?>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
      <?php 
      include_once "header.php";
      ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12 grid-margin stretch-card">
              <div class="card corona-gradient-card">
                <div class="card-body py-0 px-0 px-sm-3">
                  <div class="row align-items-center">
                    <div class="col-4 col-sm-3 col-xl-2">
                      <img src="assets/images/dashboard/Group126@2x.png" class="gradient-corona-img img-fluid" alt="">
                    </div>
                    <div class="col-5 col-sm-7 col-xl-8 p-0">
                      <h4 class="mb-1 mb-sm-0">Precisa de ajuda?</h4>
                      <p class="mb-0 font-weight-normal d-none d-sm-block">Temos suporte especializado, é só chamar!!!</p>
                    </div>
                    <div class="col-3 col-sm-2 col-xl-2 pl-0 text-center">
                      <span>
                        <a href="https://wa.me/<?=$whatsapp;?>" target="_blank" class="btn btn-outline-light btn-rounded get-started-btn">Clique para Suporte</a>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
<a href="banners.php" class="btn btn-warning mr-2">Listar Banner's</a>
          <div class="col-14 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Banner 1</h4>
                <form class="forms-sample" action="actions/banners/adicionar.php" method="post">
                  <div class="form-group">
                    <label for="title">Nome</label>
                    <input type="text" class="form-control" name="nome" id="nome" placeholder="Nome">
                  </div>
                  <div class="form-group">
                    <label for="url">URL Banner</label>
                    <input type="file" class="form-control" name="imagem" id="imagem" placeholder="URL do Banner">
                  </div>
                  <button type="submit" name="submit" class="btn btn-primary mr-2">Atualizar</button>
                  <input type="text" class="form-control" name="titulo" value="banner1" hidden>
                </form>
              </div>
            </div>
          </div>
           <div class="col-14 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Banner 2</h4>
                <form class="forms-sample" action="actions/banners/adicionar.php" method="post">
                  <div class="form-group">
                    <label for="title">Nome</label>
                    <input type="text" class="form-control" name="nome" id="nome" placeholder="Nome">
                  </div>
                  <div class="form-group">
                    <label for="url">URL Banner</label>
                    <input type="file" class="form-control" name="imagem" id="imagem" placeholder="URL do Banner">
                  </div>
                  <button type="submit" name="submit" class="btn btn-primary mr-2">Atualizar</button>
                  <input type="text" class="form-control" name="titulo" value="banner2" hidden>
                </form>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <?php
          include_once "footer.php";
          ?>
        </body>
        <?php 
        if (isset($_GET["r"])) {
          $result = $_GET["r"];
          switch ($result) {
            case "error":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'error',
                  title: 'Aconteceu algum erro, tente novamente!'
                  })
                }, 1000);</script>";
                break;
                  }
                }
                ?> 
                </html>