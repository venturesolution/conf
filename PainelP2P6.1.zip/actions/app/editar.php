<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php  
session_start();
if ($_SESSION['usuario'] == false) {
	header("Location: ../../index.php");
	exit();
}
include_once "../../sistema/functions.php";

if (isset($_POST['bg']) && isset($_POST['vod_bg']) && isset($_POST['cor1']) && isset($_POST['login_logo'])) {

	$api_dominio 	   = trim($_POST['api_dominio']);
	$api_register 	   = trim($_POST['api_register']);
	$api_auth 	   = trim($_POST['api_auth']);
	$api_email 	   = trim($_POST['api_email']);
	$api_psp 	   = trim($_POST['api_psp']);
	$login_logo 	   = trim($_POST['login_logo']);
	$sidebar_logo 	   = trim($_POST['sidebar_logo']);
	$bg 	   = trim($_POST['bg']);
	$vod_bg 	   = trim($_POST['vod_bg']);
	$trans1 	   = trim($_POST['trans1']);
	$cor1 	   = trim($_POST['cor1']);
	$trans2 	   = trim($_POST['trans2']);
	$cor2 	   = trim($_POST['cor2']);
	$trans3 	   = trim($_POST['trans3']);
	$cor3 	   = trim($_POST['cor3']);
	$info_suporte 	   = trim($_POST['info_suporte']);
	$campo1 	   = trim($_POST['campo1']);
	$campo2 	   = trim($_POST['campo2']);
	$campo3 	   = trim($_POST['campo3']);


	if(atualizarApp($api_dominio, $api_register, $api_auth, $api_email, $api_psp, $login_logo, $sidebar_logo, $bg, $vod_bg, $trans1, $cor1, $trans2, $cor2, $trans3, $cor3, $info_suporte, $campo1, $campo2, $campo3)){
		header("Location: ../../cad_app.php?r=atualizado");
	}else{
		header("Location: ../../cad_app.php?r=erro_att");
	}
}else{
	header("Location: ../../cad_app.php?r=erro_att");
}
?>