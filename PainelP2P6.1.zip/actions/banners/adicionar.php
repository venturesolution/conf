<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php  
  session_start();
  if ($_SESSION['usuario'] == false) {
    header("Location: ../../index.php");
    exit();
  }
include_once "../../sistema/functions.php";

if (isset($_POST["nome"]) && isset($_POST["imagem"])) {
	$nome 	  	 = $_POST["nome"];
	$imagem 	 = $_POST["imagem"];

	adicionarBanner($nome, $imagem);
	header("Location: ../../banners.php?r=add_sucesso");
}else{
	header("Location: ../../cad_banners.php?r=error");
}
?>