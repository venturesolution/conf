<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php  
  session_start();
  if ($_SESSION['usuario'] == false) {
    header("Location: ../../index.php");
    exit();
  }
include_once "../../sistema/functions.php";

if (isset($_POST['nome']) && isset($_POST['imagem'])) {

	$id 	   = trim($_POST['id_banner']);
	$nome 	   = trim($_POST['nome']);
	$imagem 	   = trim($_POST['imagem']);
	$link 	   = trim($_POST['link']);

	if(atualizarBanner($id, $nome, $imagem, $link)){
		header("Location: ../../banners.php?r=atualizado");
	}else{
		header("Location: ../../banners.php?r=erro_att");
	}
}else{
	header("Location: ../../banners.php?r=erro_att");
}
?>