<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php  
  session_start();
  if ($_SESSION['usuario'] == false) {
    header("Location: ../../index.php");
    exit();
  }

include_once "../../sistema/functions.php";

if (isset($_POST["banner_id"])) {
	$id   = $_POST["banner_id"];

	if (ativarDesativarBanner($id)) {
		echo true;
	}else{
		echo false;
	}
}else{
	header("location: ../../");
}


?>