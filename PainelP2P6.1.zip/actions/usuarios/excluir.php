<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php  
session_start();
if ($_SESSION['usuario'] == false) {
  header("Location: index.php?msg=erro_login");
  exit();
}

include_once "../../sistema/functions.php";

if (isset($_POST['id'])) {
  $id     = $_POST["id"];

  if(excluirUsuario($id)){
    header("Location: ../../usuarios.php?r=deletado");
  }else{
    header("Location: ../../usuarios.php?r=erro_delete");
  }
}else{
  header("Location: ../../usuarios.php?r=erro_delete");
}
?>