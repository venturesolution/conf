<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php  
session_start();
if ($_SESSION['usuario'] == false) {
  header("Location: ../../index.php");
  exit();
}
include_once "../../sistema/functions.php";

if (isset($_POST["nome"]) && isset($_POST["usuario"]) && isset($_POST["senha"])) {
  $nome        = $_POST["nome"];
  $usuario    = $_POST["usuario"];
  $senha    = $_POST["senha"];
  $nivel    = $_POST["nivel"];

  adicionarUsuario($nome, $usuario, $senha, $nivel);
  header("Location: ../../usuarios.php?r=add_sucesso");
}else{
  header("Location: ../../usuarios.php?r=error");
}
?>