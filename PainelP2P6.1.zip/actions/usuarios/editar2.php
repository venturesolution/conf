<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php  
session_start();
if ($_SESSION['usuario'] == false) {
  header("Location: index.php?msg=erro_login");
  exit();
}

include_once "../../sistema/functions.php";

if (isset($_POST['usuario']) && isset($_POST['senha'])) {
  $id2  = $_POST["id"];
  $usuario2  = $_POST["usuario"];
  $senha2    = $_POST["senha"];

if(atualizarUsuario2($id2, $usuario2, $senha2)){
    header("Location: ../../usuario.php?r=atualizado");
  }else{
    header("Location: ../../usuario.php?r=erro_att");
  }
}else{
  header("Location: ../../usuario.php?r=erro_att");
}

?>