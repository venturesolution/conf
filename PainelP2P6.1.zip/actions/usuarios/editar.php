<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php  
session_start();
if ($_SESSION['usuario'] == false) {
  header("Location: index.php?msg=erro_login");
  exit();
}

include_once "../../sistema/functions.php";

if (isset($_POST['nome']) && isset($_POST['usuario']) && isset($_POST['senha']) && isset($_POST['nivel'])) {
  $id     = $_POST["id"];
  $nome     = $_POST["nome"];
  $usuario  = $_POST["usuario"];
  $senha    = $_POST["senha"];
  $nivel    = $_POST["nivel"];

  if(atualizarUsuario($id, $nome, $usuario, $senha, $nivel)){
    header("Location: ../../usuarios.php?r=atualizado");
  }else{
    header("Location: ../../usuarios.php?r=erro_att");
  }
}else{
  header("Location: ../../usuarios.php?r=erro_att");
}
?>