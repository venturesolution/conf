
<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php 

include_once "sistema/functions.php";
$dadosApp = buscarApp(1);
$dominio = $dadosApp["api_dominio"];
$register = $dadosApp["api_register"];
$auth = $dadosApp["api_auth"];
$email = $dadosApp["api_email"];
$psp = $dadosApp["api_psp"];
$info_suporte = $dadosApp["info_suporte"];
$cor1 = $dadosApp["cor1"];
$cor2 = $dadosApp["cor2"];
$cor3 = $dadosApp["cor3"];
$trans1 = $dadosApp["trans1"];
$trans2 = $dadosApp["trans2"];
$trans3 = $dadosApp["trans3"];
$vod_bg = $dadosApp["vod_bg"];
$bg = $dadosApp["bg"];
$sidebar_logo = $dadosApp["sidebar_logo"];
$login_logo = $dadosApp["login_logo"];
$info_suporte = $dadosApp["info_suporte"];
$campo1 = $dadosApp["campo1"];
$campo2 = $dadosApp["campo2"];
$campo3 = $dadosApp["campo3"];
$api_dominio = codificarDom($dominio);
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include_once "head.php";
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_sidebar.html -->
    <?php 
    include_once "header.php";
    ?>
    <!-- partial -->
    <div class="main-panel">
      <div class="content-wrapper">
        <div class="row">
          <div class="col-12 grid-margin stretch-card">
            <div class="card corona-gradient-card">
              <div class="card-body py-0 px-0 px-sm-3">
                <div class="row align-items-center">
                  <div class="col-4 col-sm-3 col-xl-2">
                    <img src="assets/images/dashboard/Group126@2x.png" class="gradient-corona-img img-fluid" alt="">
                  </div>
                  <div class="col-5 col-sm-7 col-xl-8 p-0">
                    <h4 class="mb-1 mb-sm-0">Precisa de ajuda?</h4>
                    <p class="mb-0 font-weight-normal d-none d-sm-block">Temos suporte especializado, é só chamar!!!</p>
                  </div>
                  <div class="col-3 col-sm-2 col-xl-2 pl-0 text-center">
                    <span>
                      <a href="https://wa.me/<?=$whatsapp;?>" target="_blank" class="btn btn-outline-light btn-rounded get-started-btn">Clique para Suporte</a>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <form class="forms-sample" method="post" action="actions/app/editar.php">
<?php if($nivel == 1){?>
        <div class="col-14 grid-margin stretch-card">
          <div class="card">
            <div class="card-body col-12">
              <h4 class="card-title">Configuração do Aplicativo</h4>
                <div class="form-group">
                  <label for="url">Api Dominio: <b style="color: green;"><?php echo $api_dominio ?></b></label>
                  <input type="text" class="form-control" name="api_dominio" id="api_dominio" value="<?php echo $dominio ?>">
                </div>
                <div class="form-group">
                  <label for="url">Api Register</label>
                  <input type="text" class="form-control" name="api_register" id="api_register" value="<?php echo $register ?>">
                </div>
                <div class="form-group">
                  <label for="url">Api Auth</label>
                  <input type="text" class="form-control" name="api_auth" id="api_auth" value="<?php echo $auth ?>">
                </div>
                <div class="form-group">
                  <label for="title">Api Email</label>
                  <input type="text" class="form-control" name="api_email" value="<?php echo $email ?>">
                </div>
                <div class="form-group">
                  <label for="title">Api PSP</label>
                  <input type="text" class="form-control" name="api_psp" value="<?php echo $psp ?>">
                </div>
              </div>
            </div>
          </div>
<?php }else{?>
<input type="text" class="form-control" name="api_dominio" id="api_dominio" value="<?php echo $dominio ?>" hidden>
<input type="text" class="form-control" name="api_register" id="api_register" value="<?php echo $register ?>" hidden>
<input type="text" class="form-control" name="api_auth" id="api_auth" value="<?php echo $auth ?>" hidden>
<input type="text" class="form-control" name="api_email" value="<?php echo $email ?>" hidden>
<input type="text" class="form-control" name="api_psp" value="<?php echo $psp ?>" hidden>
<?php } ?>
        <div class="col-14 grid-margin stretch-card">
          <div class="card">
            <div class="card-body col-12">
              <h4 class="card-title">Informações do Aplicativo</h4>
                <div class="form-group">
                  <label for="url">Info Suporte: <span style="color: yellow;">Para quebra de linha coloque \n</span></label>
                  <input type="text" class="form-control" name="info_suporte" id="info_suporte" value="<?php echo $info_suporte; ?>">
                </div>
                <div class="form-group">
                  <label for="url">Titulo Aviso:</label>
                  <input type="text" class="form-control" name="campo1" id="campo1" value="<?php echo $campo1; ?>">
                </div>
                <div class="form-group">
                  <label for="url">Aviso:</label>
                  <input type="text" class="form-control" name="campo2" id="campo2" value="<?php echo $campo2; ?>">
                </div>
                <div class="form-group">
                  <label for="url">Titulo Banners</label>
                  <input type="text" class="form-control" name="campo3" id="campo3" value="<?php echo $campo3; ?>">
                </div>
              </div>
            </div>
          </div>
          <div class="col-14 grid-margin stretch-card">
            <div class="card">
              <div class="card-body col-12">
                <h4 class="card-title">Imagens do Aplicativo</h4>

                <div class="form-group">
                  <label for="title">Login Logo Atual:</label> <img src="<?php echo $login_logo ?>" width="60">
                  <input type="text" class="form-control" name="login_logo" value="<?php echo $login_logo ?>">
                </div>
                <div class="form-group">
                  <label for="url">Sidebar Logo Atual:</label> <img src="<?php echo $sidebar_logo ?>" width="60">
                  <input type="text" class="form-control" name="sidebar_logo" value="<?php echo $sidebar_logo ?>">
                </div>
                <div class="form-group">
                  <label for="url">Background Atual:</label> <img src="<?php echo $bg ?>" width="60">
                  <input type="text" class="form-control" name="bg" value="<?php echo $bg ?>">
                </div>
                <div class="form-group">
                  <label for="title">Vod Background Atual:</label> <img src="<?php echo $vod_bg ?>" width="60">
                  <input type="text" class="form-control" name="vod_bg" value="<?php echo $vod_bg ?>">
                </div>
              </div>
            </div>
          </div>
          <div class="col-14 grid-margin stretch-card">
            <div class="card">
              <div class="card-body col-12">
                <h4 class="card-title">Cores do Aplicativo</h4>

                <div class="form-group">
                  <div><label for="url">Transparência e Cor da Esquerda - Atual: <span style="color: yellow;"><?php echo transparencia($trans1);  ?></span></label></div>
                  <div style="display: inline-flex;" class="col-10">
                    <select class="form-control col-2" name="trans1">
                      <option value="<?php echo $trans1 ?>"><?php echo transparencia($trans1);  ?></option>
                      <option value="FF">100%</option>
                      <option value="E6">90%</option>
                      <option value="CC">80%</option>
                      <option value="B3">70%</option>
                      <option value="99">60%</option>
                      <option value="80">50%</option>
                      <option value="66">40%</option>
                      <option value="4D">30%</option>
                      <option value="33">20%</option>
                      <option value="1A">10%</option>
                      <option value="00">0%</option>
                    </select>
                    <input type="color" class="form-control col-5" name="cor1" value="<?php echo $cor1 ?>">
                  </div>
                </div>
                <div class="form-group">
                  <div><label for="url">Transparência e Cor Do Centro - Atual: <span style="color: yellow;"><?php echo transparencia($trans2);  ?></span></label></div>
                  <div style="display: inline-flex;" class="col-10">
                    <select class="form-control col-2" name="trans2">
                      <option value="<?php echo $trans2 ?>"><?php echo transparencia($trans2);  ?></option>
                      <option value="FF">100%</option>
                      <option value="E6">90%</option>
                      <option value="CC">80%</option>
                      <option value="B3">70%</option>
                      <option value="99">60%</option>
                      <option value="80">50%</option>
                      <option value="66">40%</option>
                      <option value="4D">30%</option>
                      <option value="33">20%</option>
                      <option value="1A">10%</option>
                      <option value="00">0%</option>
                    </select>
                    <input type="color" class="form-control col-5" name="cor2" value="<?php echo $cor2 ?>">
                  </div>
                </div>
                <div class="form-group">
                  <div><label for="url">Transparência e Cor Da Direita - Atual: <span style="color: yellow;"><?php echo transparencia($trans3);  ?></span></label></div>
                  <div style="display: inline-flex;" class="col-10">
                    <select class="form-control col-2" name="trans3">
                      <option value="<?php echo $trans3 ?>"><?php echo transparencia($trans3); ?></option>
                      <option value="FF">100%</option>
                      <option value="E6">90%</option>
                      <option value="CC">80%</option>
                      <option value="B3">70%</option>
                      <option value="99">60%</option>
                      <option value="80">50%</option>
                      <option value="66">40%</option>
                      <option value="4D">30%</option>
                      <option value="33">20%</option>
                      <option value="1A">10%</option>
                      <option value="00">0%</option>
                    </select>
                    <input type="color" class="form-control col-5" name="cor3" value="<?php echo $cor3 ?>">
                  </div>
                </div>


            </div>
          </div>
        </div>
                        <button type="submit" name="submit" class="btn btn-primary mr-2">Atualizar</button>
              </form>
        <!-- content-wrapper ends -->
        <?php
        include_once "footer.php";
        ?>
                <?php 
        if (isset($_GET["r"])) {
          $result = $_GET["r"];
          switch ($result) {
            case "atualizado":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'success',
                  title: 'Aplicativo atualizado com sucesso!'
                  })
                }, 1000);</script>";
                break;
            case "erro_att":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'error',
                  title: 'Erro ao atualizar o aplicativo!'
                  })
                }, 1000);</script>";
                break;
              }
            }
            ?> 
      </body>
      </html>