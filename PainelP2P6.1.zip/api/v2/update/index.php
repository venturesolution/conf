<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once "../../../sistema/functions.php";

//pega configuração dos campos
$buscaConfig = buscarApp();
$campo1 = urlencode($buscaConfig["campo1"]);
$campo2 = urlencode($buscaConfig["campo2"]);
$campo3 = urlencode($buscaConfig["campo3"]);

//pega os banners
$buscaB1 = buscarBannersID(1);
$nome1 = urlencode($buscaB1["nome"]);
$imagem1 = $buscaB1["imagem"];
$link1 = $buscaB1["link"];
$status1 = $buscaB1["status"];
if($status1 == 1){
$linha1 = '["'.$nome1.'","'.$imagem1.'",'.$link1.']';
}

$buscaB2 = buscarBannersID(2);
$nome2 = urlencode($buscaB2["nome"]);
$imagem2 = $buscaB2["imagem"];
$link2 = $buscaB2["link"];
$status2 = $buscaB2["status"];
if($status2 == 1){
$linha2 = ',["'.$nome2.'","'.$imagem2.'",'.$link2.']';
}

$buscaB3 = buscarBannersID(3);
$nome3 = urlencode($buscaB3["nome"]);
$imagem3 = $buscaB3["imagem"];
$link3 = $buscaB3["link"];
$status3 = $buscaB3["status"];
if($status3 == 1){
$linha3 = ',["'.$nome3.'","'.$imagem3.'",'.$link3.']';
}

$buscaB4 = buscarBannersID(4);
$nome4 = urlencode($buscaB4["nome"]);
$imagem4 = $buscaB4["imagem"];
$link4 = $buscaB4["link"];
$status4 = $buscaB4["status"];
if($status4 == 1){
$linha4 = ',["'.$nome4.'","'.$imagem4.'",'.$link4.']';
}

$buscaB5 = buscarBannersID(5);
$nome5 = urlencode($buscaB5["nome"]);
$imagem5 = $buscaB5["imagem"];
$link5 = $buscaB5["link"];
$status5 = $buscaB5["status"];
if($status5 == 1){
$linha5 = ',["'.$nome5.'","'.$imagem5.'",'.$link5.']';
}

$buscaB6 = buscarBannersID(6);
$nome6 = urlencode($buscaB6["nome"]);
$imagem6 = $buscaB6["imagem"];
$link6 = $buscaB6["link"];
$status6 = $buscaB6["status"];
if($status6 == 1){
$linha6 = ',["'.$nome6.'","'.$imagem6.'",'.$link6.']';
}

$buscaB7 = buscarBannersID(7);
$nome7 = urlencode($buscaB7["nome"]);
$imagem7 = $buscaB7["imagem"];
$link7 = $buscaB7["link"];
$status7 = $buscaB7["status"];
if($status7 == 1){
$linha7 = ',["'.$nome7.'","'.$imagem7.'",'.$link7.']';
}

$buscaB8 = buscarBannersID(8);
$nome8 = urlencode($buscaB8["nome"]);
$imagem8 = $buscaB8["imagem"];
$link8 = $buscaB8["link"];
$status8 = $buscaB8["status"];
if($status8 == 1){
$linha8 = ',["'.$nome8.'","'.$imagem8.'",'.$link8.']';
}

$buscaB9 = buscarBannersID(9);
$nome9 = urlencode($buscaB9["nome"]);
$imagem9 = $buscaB9["imagem"];
$link9 = $buscaB9["link"];
$status9 = $buscaB9["status"];
if($status9 == 1){
$linha9 = ',["'.$nome9.'","'.$imagem9.'",'.$link9.']';
}

$buscaB10 = buscarBannersID(10);
$nome10 = urlencode($buscaB10["nome"]);
$imagem10 = $buscaB10["imagem"];
$link10 = $buscaB10["link"];
$status10 = $buscaB10["status"];
if($status10 == 1){
$linha10 = ',["'.$nome10.'","'.$imagem10.'",'.$link10.']';
}
$str = '{"2":[["'.$campo1.'"],["'.$campo2.'"]],"3":[["'.$campo3.'"],['.$linha1.$linha2.$linha3.$linha4.$linha5.$linha6.$linha7.$linha8.$linha9.$linha10.']]}';

$api = codificarApi($str);
var_dump($api);
?>	
{"0":[["https://auth.wp2p.link/api/v2/register","https://auth.wp2p.link/api/v2/auth","@wp2p.link","psp.wp2p.link"]],"1":[["https://i.imgur.com/eib7iHe.png","https://i.imgur.com/s0RudqX.png","https://i.imgur.com/ocC14fm.jpg","https://i.imgur.com/ocC14fm.jpg"]],"2":[["Nome App","Nome Provider","Fale com seu \nRevendedor","#020104","#930606","#01040e"]],"3":[["0"]]}