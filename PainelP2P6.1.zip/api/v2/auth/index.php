<?php
include_once "../../../sistema/functions.php";
$app = buscarApp();
$api_dominio = $app["api_dominio"];
$login_logo = $app["login_logo"];
$sidebar_logo = $app["sidebar_logo"];
$bg = $app["bg"];
$vod_bg = $app["vod_bg"];
$info_suporte = $app["info_suporte"];
$cor1 = $app["cor1"];
$cor2 = $app["cor2"];
$cor3 = $app["cor3"];
$trans1 = $app["trans1"];
$trans2 = $app["trans2"];
$trans3 = $app["trans3"];
$api_register = $app["api_register"];
$api_auth = $app["api_auth"];
$api_email = $app["api_email"];
$api_psp = $app["api_psp"];

$strCor1 = array(
        '#' => ''
        );
$cor1 = strtr($cor1, $strCor1);

$strCor2 = array(
        '#' => ''
        );
$cor2 = strtr($cor2, $strCor2);

$strCor3 = array(
        '#' => ''
        );
$cor3 = strtr($cor3, $strCor3);


$str = '
{"0":[["'.$api_register.'","'.$api_auth.'","'.$api_email.'","'.$api_psp.'"]],"1":[["'.$login_logo.'","'.$sidebar_logo.'","'.$bg.'","'.$vod_bg.'"]],"2":[["Nome App","Nome Provider","'.$info_suporte.'","#'.$trans1.$cor1.'","#'.$trans2.$cor2.'","#'.$trans3.$cor3.'"]],"3":[["0"]]}';


$api = codificarApi($str);
var_dump($api);
?>