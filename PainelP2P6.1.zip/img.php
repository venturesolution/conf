<!DOCTYPE html>
<html lang="pt-BR">
<?php
include_once "head.php";

function clearUrl()
{
  echo '
    <script type="text/javascript">
        window.location.href = "img.php";
    </script>
    ';
}

//pegar link dinamicamente
if (isset($_SERVER['HTTPS'])) {
  $link_parts = explode("img.php", "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
  $link = $link_parts[0];
} else {
  $link_parts = explode("img.php", "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
  $link = $link_parts[0];
}

//insert
if (isset($_GET['insert'])) {

  $arquivo = $_FILES['arquivo'];

  if ($arquivo !== null) {

    $caminho = 'assets/uploads/';
    $img = glob($caminho . "*.{jpg,png}", GLOB_BRACE);
    $contador = count($img);

    if ($contador < 14) {
      preg_match("/\.(png|jpg){1}$/i", $arquivo["name"], $ext);

      if ($ext == true) {

        $caminho_arquivo = "./assets/uploads/" . $arquivo["name"];
        move_uploaded_file($arquivo["tmp_name"], $caminho_arquivo);
        clearUrl();
      } else {

        echo '<script>alert("São suportados apenas arquivos nos formatos png ou jpg!")</script>';
        clearUrl();
      }
    } else {

      echo '<script>alert("Você excedeu o limite de 14 arquivos!")</script>';
      clearUrl();
    }
  }
}

if (isset($_GET['delete'])) {

  unlink($_GET['delete']);
  clearUrl();
}

?>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_sidebar.html -->
    <?php
    include_once "header.php";
    ?>
    <!-- partial -->
    <div class="main-panel">
      <div class="content-wrapper">
        <div class="row">
          <div class="col-12 grid-margin stretch-card">
            <div class="card corona-gradient-card">
              <div class="card-body py-0 px-0 px-sm-3">
                <div class="row align-items-center">
                  <div class="col-4 col-sm-3 col-xl-2">
                    <img src="assets/images/dashboard/Group126@2x.png" class="gradient-corona-img img-fluid" alt="">
                  </div>
                  <div class="col-5 col-sm-7 col-xl-8 p-0">
                    <h4 class="mb-1 mb-sm-0">Precisa de ajuda?</h4>
                    <p class="mb-0 font-weight-normal d-none d-sm-block">Temos suporte especializado, é só chamar!!!</p>
                  </div>
                  <div class="col-3 col-sm-2 col-xl-2 pl-0 text-center">
                    <span>
                      <a href="https://wa.me/<?= $whatsapp; ?>" target="_blank" class="btn btn-outline-light btn-rounded get-started-btn">Clique para Suporte</a>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <a href="banners.php" class="btn btn-warning mr-2">Listar Banner's</a>
        <div class="col-14 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Enviar imagem</h4>
              <form class="forms-sample" action="<?php echo $_SERVER['PHP_SELF'] . '?insert=1'; ?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <input type="file" class="form-control" name="arquivo" placeholder="Selecionar imagem">
                </div>
                <button type="submit" name="submit" class="btn btn-primary mr-2">Enviar</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-14 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Imagens enviadas / (1240 x 480)</h4>
              <!-- <p class="card-description"> Add class <code>.table-dark</code>
                    </p> -->
              <div class="table-responsive">
                <table class="table table-dark">
                  <thead>
                    <tr>
                      <th> Imagem </th>
                      <th> URL </th>
                      <th> Ação </th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php
                    $caminho = 'assets/uploads/';
                    $img = glob($caminho . "*.{jpg,png}", GLOB_BRACE);
                    $contador = count($img);

                    if ($contador == 0) {
                      echo '<tr><td  colspan="4" style="color:#fec60f;" <p class="text-center"><i class="fas fa-inbox" style="font-size: 40px;"></i><br>Não há imagens enviadas!</p></td></tr>';
                    } else {

                      foreach ($img as $img) {
                    ?>
                        <tr>
                          <td>
                            <img src="<?php echo $img ?>" width="75px" height="146px" alt="">
                          </td>
                          <td><b style="color:#fec60f"><?php echo $link . $img; ?></b></td>
                          <td>
                            <a href="img.php?delete=<?php echo $img; ?>" class="btn btn-danger mr-2">DELETAR</a>
                          </td>
                        </tr>
                    <?php
                      }
                    }
                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <?php
        include_once "footer.php";
        ?>
</body>
<?php
if (isset($_GET["r"])) {
  $result = $_GET["r"];
  switch ($result) {
    case "error":
      echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'error',
                  title: 'Aconteceu algum erro, tente novamente!'
                  })
                }, 1000);</script>";
      break;
  }
}
?>

</html>