<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php 
include_once "sistema/functions.php";
$id_banner = $_GET['update'];
$buscarBanner = buscarBannersID($id_banner);
$nome_banner = $buscarBanner["nome"];
$imagem_banner = $buscarBanner["imagem"];
$link = $buscarBanner["link"];
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include_once "head.php";
?>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
<?php 
include_once "header.php";
?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card corona-gradient-card">
                  <div class="card-body py-0 px-0 px-sm-3">
                    <div class="row align-items-center">
                      <div class="col-4 col-sm-3 col-xl-2">
                        <img src="assets/images/dashboard/Group126@2x.png" class="gradient-corona-img img-fluid" alt="">
                      </div>
                      <div class="col-5 col-sm-7 col-xl-8 p-0">
                        <h4 class="mb-1 mb-sm-0">Precisa de ajuda?</h4>
                        <p class="mb-0 font-weight-normal d-none d-sm-block">Temos suporte especializado, é só chamar!!!</p>
                      </div>
                      <div class="col-3 col-sm-2 col-xl-2 pl-0 text-center">
                        <span>
                          <a href="https://wa.me/<?=$whatsapp;?>" target="_blank" class="btn btn-outline-light btn-rounded get-started-btn">Clique para Suporte</a>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

<div class="col-14 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Editar Banner's</h4>
                    <form class="forms-sample" action="actions/banners/editar.php" method="post">
                      <input type="hidden" class="form-control" name="id_banner" value="<?=$id_banner;?>">
                      <div class="form-group">
                        <label for="title">Nome</label>
                        <input type="text" class="form-control" name="nome" id="nome" value="<?=$nome_banner;?>">
                      </div>
                      <div class="form-group">
                        <label for="url">URL Banner</label>
                        <input type="text" class="form-control" name="imagem" id="imagem" value="<?=$imagem_banner;?>">
                      </div>
                      <div class="form-group">
                        <label for="url">Link Atual: <b style="color: green;">
                        <?php 
                          if($link == 2){
                            $linkN = "Canais";
                          }if($link == 1){
                            $linkN = "VODs";
                          }if($link < 1){
                            $linkN = "Nenhum";
                          }
                        echo $linkN;?></b></label>
                        <select name="link" class="form-control">
                          <option value="<?php echo $link; ?>">Selecione ou deixe branco</option>
                          <option value="2">Canais</option>
                          <option value="1">VODs</option>
                        </select>
                      </div>
                      <button type="submit" name="submit" class="btn btn-primary mr-2">Editar</button>
                    </form>
                  </div>
                </div>
              </div>
          <!-- content-wrapper ends -->
<?php
include_once "footer.php";
?>
  </body>
</html>