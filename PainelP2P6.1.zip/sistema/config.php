<?php
/* CONFIGURAÇÕES DO BANCO DE DADOS DO GESTOR */
define("DB_HOST", "localhost");
define("DB_PORT", "3306");
define("DB_NAME", "minerd_p2p");
define("DB_USER", "batmonn");
define("DB_PASS", "151741@2565011");

/* ENABLE DEBUG LOG */
define("OFFICE_DEBUG", 1);

$whatsapp = "559999999999";
$titulo_site = "Painel Admin P2P Plus";
