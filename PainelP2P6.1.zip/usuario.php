<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php
include_once "sistema/functions.php";
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include_once "head.php";
?>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
<?php 
include_once "header.php";
?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card corona-gradient-card">
                  <div class="card-body py-0 px-0 px-sm-3">
                    <div class="row align-items-center">
                      <div class="col-4 col-sm-3 col-xl-2">
                        <img src="assets/images/dashboard/Group126@2x.png" class="gradient-corona-img img-fluid" alt="">
                      </div>
                      <div class="col-5 col-sm-7 col-xl-8 p-0">
                        <h4 class="mb-1 mb-sm-0">Precisa de ajuda?</h4>
                        <p class="mb-0 font-weight-normal d-none d-sm-block">Temos suporte especializado, é só chamar!!!</p>
                      </div>
                      <div class="col-3 col-sm-2 col-xl-2 pl-0 text-center">
                        <span>
                          <a href="https://wa.me/<?=$whatsapp;?>" target="_blank" class="btn btn-outline-light btn-rounded get-started-btn">Clique para Suporte</a>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<?php
if(isset($_GET['msg'])){
if($_GET["msg"] == "sucesso"){?>
<div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Sucesso!</h4>
  <hr>
  <p class="mb-0">Seus dados foram alterados.</p>
</div>
<?php
}else{
  ?>
<div class="alert alert-danger" role="alert">
  <h4 class="alert-heading">Erro!</h4>
  <hr>
  <p class="mb-0">Seus dados não foram alterados.</p>
</div>
<?php
}
}
?>
<div class="col-14 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Editar Meus Dados</h4>
                    <form class="forms-sample" method="post" action="actions/usuarios/editar2.php">
                      <div class="form-group">
                        <label for="title">Usuário</label>
                        <input type="text" class="form-control" name="usuario" id="usuario" value="<?=$usuario;?>">
                      </div>
                      <div class="form-group">
                        <label for="url">Senha</label>
                        <input type="text" class="form-control" name="senha" id="senha" value="<?=$senha;?>">
                      </div>
                      <input type="text" class="form-control" name="id" id="id" value="<?=$id_sessao;?>" hidden>
                      <button type="submit" name="submit" class="btn btn-primary mr-2">Editar</button>
                    </form>
                  </div>
                </div>
              </div>
          <!-- content-wrapper ends -->
<?php
include_once "footer.php";
?>
        <?php 
        if (isset($_GET["r"])) {
          $result = $_GET["r"];
          switch ($result) {
            case "add_sucesso":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'success',
                  title: 'Usuario cadastrado com sucesso!'
                  })
                }, 1000);</script>";
                break;
            case "atualizado":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'success',
                  title: 'Usuario atualizado com sucesso!'
                  })
                }, 1000);</script>";
                break;
            case "erro_att":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'error',
                  title: 'Erro ao atualizar o Usuario!'
                  })
                }, 1000);</script>";
                break;
            case "erro_delete":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'error',
                  title: 'Erro ao excluir o Usuario!'
                  })
                }, 1000);</script>";
                break;
            case "deletado":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'success',
                  title: 'Usuario excluido com sucesso!'
                  })
                }, 1000);</script>";
                break;
              }
            }
            ?> 
  </body>
</html>