<!--
=========================================================
Painel P2P Plus - v1.0
=========================================================
Created by Albeci Nogueira (PLAYLIVE.TOP)
=========================================================
-->
<?php 
include_once "sistema/functions.php";
$banners = buscarBanners();
?>
<!DOCTYPE html>
<html lang="en">
<?php 
include_once "head.php";
?>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
<?php 
include_once "header.php";
?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card corona-gradient-card">
                  <div class="card-body py-0 px-0 px-sm-3">
                    <div class="row align-items-center">
                      <div class="col-4 col-sm-3 col-xl-2">
                        <img src="assets/images/dashboard/Group126@2x.png" class="gradient-corona-img img-fluid" alt="">
                      </div>
                      <div class="col-5 col-sm-7 col-xl-8 p-0">
                        <h4 class="mb-1 mb-sm-0">Precisa de ajuda?</h4>
                        <p class="mb-0 font-weight-normal d-none d-sm-block">Temos suporte especializado, é só chamar!!!</p>
                      </div>
                      <div class="col-3 col-sm-2 col-xl-2 pl-0 text-center">
                        <span>
                          <a href="https://wa.me/<?=$whatsapp;?>" target="_blank" class="btn btn-outline-light btn-rounded get-started-btn">Clique para Suporte</a>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<?php
if(isset($_GET['msg'])){
if($_GET["msg"] == "sucesso"){?>
<div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Sucesso!</h4>
  <hr>
  <p class="mb-0">Seus dados foram alterados.</p>
</div>
<?php
}else{
  ?>
<div class="alert alert-danger" role="alert">
  <h4 class="alert-heading">Erro!</h4>
  <hr>
  <p class="mb-0">Seus dados não foram alterados.</p>
</div>
<?php
}
}
?>
            <div class="col-lg-14 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Banner's Cadastrados / (1240 x 480)</h4>
                    <!-- <p class="card-description"> Add class <code>.table-dark</code>
                    </p> -->
                    <div class="table-responsive">
                      <table class="table table-dark">
                        <thead>
                          <tr>
                            <th> # </th>
                            <th> Nome</th>
                            <th> Banner URL </th>
                            <th> Imagem </th>
                            <th> Link </th>
                            <th> AÇÕES </th>
                          </tr>
                        </thead>
                        <?php
                        foreach ($banners as $value) {
                          $id = $value['id'];
                          $nome = $value['nome'];
                          $imagem = $value['imagem'];
                          $link = $value['link'];
                          $status = $value['status'];
                          ?>
                        <tbody>
                          <tr>
                          <td><?php echo $id;?></td>
                          <td><?php echo $nome;?></td>
                          <td><?php echo $imagem;?></td>
                          <td class="item">
                            <img src="<?=$imagem;?>" width="100"></td>
                          <td><?php
                          if($link == 2){
                            $linkN = "Canais";
                          }if($link == 1){
                            $linkN = "VODs";
                          }if($link == 0){
                            $linkN = "Nenhum";
                          }
                           echo $linkN;?></td>
                           <td>
                          <a href="edit_banners.php?update=<?=$id?>" alt="Editar">  
                          <button type="button" class="btn btn-inverse-primary btn-rounded btn-icon">
                            <i class="mdi mdi-lead-pencil"></i>
                          </button></a>

                          <button type="button" class="btn btn-<?php echo $status == 1 ? "success" : "danger"; ?> btn-rounded btn-icon" id="<?php echo $id?>" alt="Ativar/Desativar" onclick="AtivarDesativarBanner(this)" <?php echo $id == 1 ? "disabled" : ""; ?>>
                            <i class="mdi mdi <?php echo $status == 1 ? "mdi-eye" : "mdi-eye-off"; ?>"></i>
                          </button>
                        </td>
                          </tr>
                    </tbody>
                            <?php } ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
                  <!-- <a href="cad_banners.php" class="btn btn-primary btn-rounded btn-fw">Cadastrar Banner</button></a> -->
          <!-- content-wrapper ends -->
          <?php
          include_once "footer.php";
          ?>
        </body>
        <script type="text/javascript">
      function AtivarDesativarBanner(obj){

        const swalWithBootstrapButtons = Swal.mixin({
          customClass: {
            confirmButton: 'btn btn-success',
            cancelButton: 'btn btn-danger'
          },
          buttonsStyling: false
        })


        Swal.fire({
          title: 'Ativar/Desativar esse Banner?',
          text: "Deseja realmente Ativar/Desativar esse banner?",
          icon: 'question',
          showCancelButton: true,
          confirmButtonColor: '#7B67FE',
          cancelButtonColor: '#F73567',
          confirmButtonText: 'Sim, tenho certeza!'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              type: "POST",
              url: "actions/banners/status.php",
              data: "banner_id="+obj.id,
              cache: false,
              success: function(response) {
                if (response) {
                  Swal.fire(
                    'Banner Ativado/Desativado',
                    'Seu Banner foi Ativado/Desativado com sucesso',
                    'success'
                    )

                  setTimeout(function() {
                    document.location.reload(true);
                  }, 2000);
                }else{
                  Swal.fire(
                    'Erro ao Ativar/Desativar!',
                    'Seu Banner não foi Ativado/Desativado, aconteceu um erro',
                    'error'
                    )
                }
              }
            });
          }else if (
            /* Read more about handling dismissals below */
            result.dismiss === Swal.DismissReason.cancel
            ) {
            swalWithBootstrapButtons.fire(
              'Cancelado',
              'Sua ação foi cancelada a tempo. Tome cuidado ao realizar qualquer ação de exclusão dentro do gestor. Não será possível reverter a sua ação.',
              'error'
              )
          }
        })
      }
    </script>
        <?php 
        if (isset($_GET["r"])) {
          $result = $_GET["r"];
          switch ($result) {
            case "add_sucesso":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'success',
                  title: 'Banner cadastrado com sucesso!'
                  })
                }, 1000);</script>";
                break;
            case "atualizado":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'success',
                  title: 'Banner atualizado com sucesso!'
                  })
                }, 1000);</script>";
                break;
            case "erro_att":
            echo "<script>
            setTimeout(function() {
              const Toast = Swal.mixin({
                toast: true,
                position: 'bottom-start',
                showConfirmButton: false,
                timer: 7000
                })
                Toast.fire({
                  type: 'error',
                  title: 'Erro ao atualizar o banner!'
                  })
                }, 1000);</script>";
                break;
              }
            }
            ?> 

            </html>