<?php

include __DIR__.'/../includes/includes.php';
/*$tlg = new Telegram ('5777177877:AAHJFs4vmafwenqrYrc4rrJfRhV1Q0QuMbM');*/
$tlg = new Telegram ('8106448013:AAFOup2tzRQKBdQHA3r7DuPbuePMvSfwbAQ');
print_r ($tlg->sendDocument ([
	'chat_id' => 1952104281,
	'caption' => "Backup\n@smsservices\n".date ('d/m/Y H:i:s'),
	'document' => curl_file_create (__DIR__.'/../recebersmsbot.db')
]));