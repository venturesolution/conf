<?php

$userid = $message["from"]["id"];


if ($text == '/hope') {
    $userid;

    file_get_contents($website."/sendmessage?chat_id=".$chatId.);
}