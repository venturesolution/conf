Upload the files of the .zip to your Webhosting and configure your panel.
(Change default username and password from `admin`)

+++++
Editing APK:
+++++

Your Current API Url: https://yourportal/stremio/api/stremio/


+++++
Debrid Services:
+++++
Get your Premiumize api key from: https://www.premiumize.me/account
Get your Real-Debrid api key from: https://real-debrid.com/apitoken
Get your AllDebrid api key from: https://alldebrid.com/apikeys
Get your DebridLink api key from: https://debrid-link.fr/webapp/apikey
Get your OffCloud api key from: https://offcloud.com/#/account