<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <div id="sidebar-menu">

            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Cockpit Menu</li>
                <?php
                if ($DASHBOARD == true) {
                    echo '<li>
                            <a href="dashboard.php" class="waves-effect">
                                <i class="ri-dashboard-line"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>';
                }
                ?>

                <li class="menu-title">Added Extras</li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="ri-android-line"></i>
                        <span>Stremio</span>
                    </a>

                    <ul class="sub-menu" aria-expanded="true">
                        <li>
                            <a href="stremio_domains.php">
                                <span><i class="ri-global-line"></i>Service List</span>
                            </a>
                        </li>
                        <li>
                            <a href="stremio_customers.php">
                                <span><i class="ri-user-add-line"></i>Extra Customers</span>
                            </a>
                        </li>
                        <li>
                            <a href="stremio_debrid.php">
                                <span><i class="ri-key-line"></i>Debrid Services</span>
                            </a>
                        </li>
                        
                    </ul>
                </li>

            </ul>
        </div>
    </div>
</div>