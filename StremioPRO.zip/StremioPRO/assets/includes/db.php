<?php
$sqlite3 = new SQLite3('./api/.cockpit-0001.db');

/* create table `profile` if not exists */
$sql = 'CREATE TABLE IF NOT EXISTS profile(';
$sql .= 'id INTEGER PRIMARY KEY, ';
$sql .= 'profile_name TEXT, ';
$sql .= 'username TEXT, ';
$sql .= 'password TEXT, ';
$sql .= 'avatar_url TEXT);';
$sqlite3->exec($sql);

/* create table `panel` if not exists */
$sql = 'CREATE TABLE IF NOT EXISTS panel(';
$sql .= 'title TEXT, ';
$sql .= 'logo_light TEXT, ';
$sql .= 'logo_dark TEXT, ';
$sql .= 'logo_light_sm TEXT, ';
$sql .= 'logo_dark_sm TEXT, ';
$sql .= 'login_gif TEXT);';
$sqlite3->exec($sql);

/* create table `snoop_logs` if not exists */
$sql = 'CREATE TABLE IF NOT EXISTS snoop_logs(';
$sql .= 'id INTEGER PRIMARY KEY, ';
$sql .= 'ip TEXT, ';
$sql .= 'date TEXT);';
$sqlite3->exec($sql);

/* create table `xc_domains_stremio` if not exists */
$sql = 'CREATE TABLE IF NOT EXISTS xc_domains_stremio(';
$sql .= 'id INTEGER PRIMARY KEY, ';
$sql .= 'name TEXT, ';
$sql .= 'ssl TEXT, ';
$sql .= 'dns TEXT, ';
$sql .= 'port TEXT);';
$sqlite3->exec($sql);

/* create table `extra_customers_stremio` if not exists */
$sql = 'CREATE TABLE IF NOT EXISTS extra_customers_stremio(';
$sql .= 'id INTEGER PRIMARY KEY, ';
$sql .= 'username TEXT, ';
$sql .= 'password TEXT, ';
$sql .= 'status TEXT, ';
$sql .= 'expiry TEXT);';
$sqlite3->exec($sql);

/* create table `api_keys` if not exists */
$sql = 'CREATE TABLE IF NOT EXISTS stremio_debrid(';
$sql .= 'id INTEGER PRIMARY KEY, ';
$sql .= 'debrid_service TEXT, ';
$sql .= 'key TEXT);';
$sqlite3->exec($sql);

/* get user count */
$result = $sqlite3->query("SELECT COUNT(*) AS count FROM profile");
$row = $result->fetchArray();
$row_count = $row['count'];
if ($row_count == 0) {
  /* insert `admin` if not exists */
  $sql = 'INSERT INTO profile(';
  $sql .= 'id, ';
  $sql .= 'profile_name, ';
  $sql .= 'username, ';
  $sql .= 'password, ';
  $sql .= 'avatar_url) ';
  $sql .= 'VALUES(';
  $sql .= '1, ';
  $sql .= '"Admin", ';
  $sql .= '"admin", ';
  $sql .= '"admin", ';
  $sql .= '"https://i.imgur.com/0r65LVT.jpg");';
  $sqlite3->exec($sql);

  /* inserts default images */
  $sql = 'INSERT INTO panel(';
  $sql .= 'logo_light, ';
  $sql .= 'logo_dark, ';
  $sql .= 'logo_light_sm, ';
  $sql .= 'logo_dark_sm, ';
  $sql .= 'login_gif) ';
  $sql .= 'VALUES(';
  $sql .= '"https://i.imgur.com/6wvFmRC.png", ';
  $sql .= '"https://i.imgur.com/IrhBb1p.png", ';
  $sql .= '"https://i.imgur.com/HgTuiLC.png", ';
  $sql .= '"https://i.imgur.com/HgTuiLC.png", ';
  $sql .= '"https://i.imgur.com/Kj3bflW.gif");';
  $sqlite3->exec($sql);
}

$sql = "SELECT * FROM profile ";
$sql .= "WHERE id = '1';";
$result = $sqlite3->query($sql);
$profile_data = $result->fetchArray();

$sql = "SELECT * FROM panel;";
$result = $sqlite3->query($sql);
$panel_data = $result->fetchArray();

$sql = "SELECT * FROM snoop_logs;";
$snoop_logs = $sqlite3->query($sql);

$sql = "SELECT * FROM xc_domains_stremio;";
$service_stremio_data = $sqlite3->query($sql);

$sql = "SELECT * FROM extra_customers_stremio;";
$customer_stremio_data = $sqlite3->query($sql);

$sql = "SELECT * FROM stremio_debrid;";
$result = $sqlite3->query($sql);
$stremio_debrid_data = $result->fetchArray();
$stremio_debrid_table = $sqlite3->query($sql);
