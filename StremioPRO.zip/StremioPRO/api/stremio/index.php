<?php
try {
    $pdo = null;
    $pdo = new PDO('sqlite:../../api/.cockpit-0001.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $accounts_query = $pdo->query('SELECT * FROM stremio_debrid WHERE debrid_service = \'premiumize\' ORDER BY RANDOM() LIMIT 1');
    $stremio_premiumize = $accounts_query->fetch(PDO::FETCH_ASSOC);    

    $services_query = $pdo->query('SELECT * FROM xc_domains_stremio');
    $stremio_services = $services_query->fetchAll(PDO::FETCH_ASSOC);

    $serviceList = array();
    foreach ($stremio_services as $service) {
        if ($service['ssl'] == 'true') {
            $url = 'https://';
        } else {
            $url = 'http://';
        }
        $url .= $service['dns'] . ':' . $service['port'];
        array_push($serviceList, array(
            'name' => $service['name'],
            'url' => $url
        ));
    }
    
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $directory = dirname($_SERVER['PHP_SELF']);

    array_push($serviceList, array(
        'name' => 'Cockpit Panel',
        'url' => $protocol . $host . $directory . '/player_api.php'
    ));

    $jsonData = array(
        'portals' => $serviceList,
        'key' => $stremio_premiumize['key'] ?? ''
    );

    $inputData = json_encode($jsonData);

    // echo $inputData;

    $get_enc_url = 'https://us-central1-leave-our-shit-alone-next-time.cloudfunctions.net/app/UXNrR1VGUU15Nkt0aldkMQ==/MWRXanRLNnlNUUZVR2tzUQ==';
    $curl = curl_init($get_enc_url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $inputData);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array("content-type: application/json;charset=utf-8"));

    header('Content-Type: application/json');
    $enc_response = curl_exec($curl);

    $pdo = null;
} catch (PDOException $e) {
    echo json_encode(array('error' => 'Database error: ' . $e->getMessage()));
}
