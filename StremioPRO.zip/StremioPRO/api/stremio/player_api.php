<?php
date_default_timezone_set('UTC');

$db = new SQLite3('../../api/.cockpit-0001.db');

if (isset($_GET['username']) && isset($_GET['password'])) {
    $sql = 'SELECT * FROM extra_customers_stremio ';
    $sql .= 'WHERE username="' . $_GET['username'] . '";';
    $customer_data = $db->query($sql);

    while ($customer_row = $customer_data->fetchArray()) {
        $customer_id = $customer_row['id'];
        $customer_username = $customer_row['username'];
        $customer_password = $customer_row['password'];
        $customer_status = $customer_row['status'];
        $customer_expiry = $customer_row['expiry'];
    }

    if (@$customer_status == 'Active' && (strtotime($customer_expiry) > time()) == 1) {
        if ($_GET['username'] == $customer_username && $_GET['password'] == $customer_password) {
            echo json_response(new UserInfoConfig($customer_username, $customer_password, 1, $customer_status));
        }
    } else {
        echo json_response(null);
    }
} else {
    echo json_response(null);
}

function json_response($message = null) {
    header_remove();
    http_response_code(200);
    header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
    header('Status: 200');
    return json_encode(array(
        'user_info' => $message
    ));
}

class UserInfoConfig {
    public $username = '';
    public $password = '';
    public $auth = '0';
    public $status = '0';
    public $is_trial = '0';
    public $created_at = '612835200';
    public $max_connections = '0';
    public $active_conns = '0';
    function __construct($username = '', $password = '', $auth = '0', $status = '0') {
        $this->username = $username;
        $this->password = $password;
        $this->auth = $auth;
        $this->status = $status;
    }
}