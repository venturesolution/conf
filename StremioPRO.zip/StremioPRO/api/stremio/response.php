<?php
echo '{"status": "ok"}';
exit;