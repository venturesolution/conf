<?php

try {
    $pdo = new PDO('sqlite:../../../api/.cockpit-0001.db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $torrentioLink = 'https://torrentio.strem.fun/debridoptions=nodownloadlinks,nocatalog';
    $debridServices = ['realdebrid', 'premiumize', 'alldebrid', 'debridlink', 'offcloud'];
    $manifest = '/manifest.json';
    function getDebridKey($pdo, $service)
    {
        $query = $pdo->prepare('SELECT `key` FROM stremio_debrid WHERE debrid_service = :service ORDER BY RANDOM() LIMIT 1');
        $query->execute([':service' => $service]);
        $key = $query->fetch(PDO::FETCH_ASSOC);
        return $key ? '|' . $service . '=' . $key['key'] : '';
    }
    foreach ($debridServices as $service) {
        ${$service} = getDebridKey($pdo, $service);
    }
    $torrentioLink .= $realdebrid . $premiumize . $alldebrid . $debridlink . $offcloud . $manifest;
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
} finally {
    $pdo = null;
}

if (isset($_GET['type']) && $_GET['type'] == 'Create') {
    $stremioCreateUrl = 'https://link.stremio.com/api/create?type=Create';
    $curl = curl_init($stremioCreateUrl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $stremioCreateJson = curl_exec($curl);
    echo $stremioCreateJson;
} else if (isset($_GET['code']) && isset($_GET['type']) && $_GET['type'] == 'Read') {
    $ianRegisterUrl = 'https://us-central1-stremio-ian.cloudfunctions.net/app/' . $_GET['code'];
    $curl = curl_init($ianRegisterUrl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $ianRegisterJson = curl_exec($curl);
    if (curl_errno($curl)) {
        echo '{"status": "error", "message": "cURL error: ' . curl_error($curl) . '"}';
        exit;
    }
    curl_close($curl);
    $ianRegisterArray = json_decode($ianRegisterJson, true);
    if (isset($ianRegisterArray['status']) && $ianRegisterArray['status'] == 'ok') {
        $stremioReadUrl = 'https://link.stremio.com/api/read?type=Read&code=' . $_GET['code'];
        $curl = curl_init($stremioReadUrl);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $stremioReadJson = curl_exec($curl);
        $stremioReadArray = json_decode($stremioReadJson, true);
        if (isset($stremioReadArray['data']['authKey'])) {
            $authKey = $stremioReadArray['data']['authKey'];
            $jsonData = file_get_contents('addonCollectionSet.json');
            $jsonArray = json_decode($jsonData, true);
            $jsonArray['authKey'] = $authKey;
            foreach ($jsonArray['addons'] as $key => $value) {
                if (isset($value['manifest']['id']) && $value['manifest']['id'] == 'com.stremio.torrentio.addon') {
                    if (isset($jsonArray['addons'][$key]['transportUrl'])) {
                        $jsonArray['addons'][$key]['transportUrl'] = $torrentioLink;
                        break;
                    } else {
                        echo "Error: 'transportUrl' not found for the addon with manifest->id=com.stremio.torrentio.addon";
                    }
                }
            }
            $newJsonData = json_encode($jsonArray);
            file_put_contents('addonCollectionSet.json', $newJsonData);
            $jsonData = file_get_contents('addonCollectionSet.json');
            $stremioEventsUrl = 'https://api.strem.io/api/addonCollectionSet';
            $curl = curl_init($stremioEventsUrl);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Content-Length: ' . strlen($jsonData),
                'Accept: */*',
                'User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) QtWebEngine/5.15.2 Chrome/83.0.4103.122 Safari/537.36 StremioShell/4.4.165',
                'Origin: https://app.strem.io',
                'Referer: https://app.strem.io/shell-v4.4/'
            ]);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonData);
            $stremioEventsJson = curl_exec($curl);
            $stremioEventsArray = json_decode($stremioEventsJson, true);
        } else {
            echo '{"status": "error", "message": "authKey not found in response."}';
        }
        if (curl_errno($curl)) {
            echo '{"status": "error", "message": "cURL error: ' . curl_error($curl) . '"}';
            exit;
        }
        curl_close($curl);
        echo $stremioReadJson;
    } else {
        echo '{"status": "error", "message": "ianRegisterJson status is not ok."}';
    }
} else {
    echo '{"status": "ok"}';
    exit;
}
