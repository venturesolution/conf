<?php
ob_start();
session_start();

include('assets/includes/db.php');
include('assets/includes/config.php');

if($_ERRORS == true){
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    header("Location: dashboard.php");
    exit;
}

$id = null;
$_SESSION['loggedin'] = false;
$_SESSION['username'] = null;
$_SESSION['profile_name'] = null;
$_SESSION['avatar_url'] = null;

if (isset($_POST["login"])) {

    $sql = 'SELECT * FROM profile ';
    $sql .= 'WHERE username = "' . $_POST["username"] . '";';
    $result = $sqlite3->query($sql);
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $id = $row['id'];
        $username = $row['username'];
        $password = $row['password'];
        $profile_name = $row['profile_name'];
        $avatar_url = $row['avatar_url'];

        if (isset($id)) {
            if ($password == $_POST["password"]) {
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $_POST['username'];
                $_SESSION['profile_name'] = $_POST['profile_name'];
                $_SESSION['avatar_url'] = $_POST['avatar_url'];

                if ($_POST['username'] == "admin" && $_POST['password'] == "admin") {
                    $_SESSION['loggedin'] = true;
                    header("location: profile_edit.php");
                    exit;
                } else {
                    $_SESSION['loggedin'] = true;

                    if ($DASHBOARD == true) {
                        header("Location: dashboard.php");
                        exit;
                    } else {
                        header("Location: profile_edit.php");
                        exit;
                    }
                }
            } else {
                header("Location: ./api/index.php");
                exit;
            }
        } else {
            header("Location: ./api/index.php");
            exit;
        }
    }
}
ob_end_flush();
?>
<!doctype html>
<html lang="en">

<head>

    <?php include('./assets/includes/title-meta.php'); ?>

    <?php include('./assets/includes/head-css.php'); ?>

</head>

<body class="auth-body-bg">
    <div>
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-lg-4">
                    <div class="authentication-page-content p-4 d-flex align-items-center min-vh-100">
                        <div class="w-100">
                            <div class="row justify-content-center">
                                <div class="col-lg-9">
                                    <form method="POST">
                                        <div class="text-center">
                                            <div>
                                                <img src="<?php echo $USER_PROFILE_PANEL_EDITS ? $panel_data['logo_light'] : $USER_PROFILE_PANEL_LOGO_LIGHT; ?>" height="20" alt="logo">
                                            </div>

                                            <h4 class="font-size-18 mt-4">Welcome Back !</h4>
                                            <p class="text-muted">Sign in to continue.</p>
                                        </div>

                                        <div class="p-2 mt-5">
                                            <form class="form-horizontal" action="index.php">

                                                <div class="form-group auth-form-group-custom mb-4">
                                                    <i class="ri-user-2-line auti-custom-input-icon"></i>
                                                    <label for="username">Username</label>
                                                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
                                                </div>

                                                <div class="form-group auth-form-group-custom mb-4">
                                                    <i class="ri-lock-2-line auti-custom-input-icon"></i>
                                                    <label for="userpassword">Password</label>
                                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter password">
                                                </div>

                                                <div class="mt-4 text-center">
                                                    <button class="btn btn-primary w-md waves-effect waves-light" type="submit" name="login">Log In</button>
                                                </div>
                                            </form>
                                        </div>

                                        <?php if ($IPTVAPPS_BRANDING) { ?>
                                        <div class="mt-5 text-center">
                                            <p>
                                                <script>
                                                    document.write(new Date().getFullYear())
                                                </script> © IPTVApps.net
                                            <p></P>
                                            Crafted with <i class="mdi mdi-heart text-danger"></i> by <a href="https://iptvapps.net/members/ian.11/">Ian</a> & <a href="https://iptvapps.net/members/jlwockee.3/">Jlwockee</a>
                                            </p>
                                        </div>
                                    <?php } ?>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="authentication-bg">
                        <div class="bg-overlay"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include('assets/includes/vendor-scripts.php'); ?>

    <script src="assets/js/app.js"></script>
    <style>
        .authentication-bg {
            background-image: url(<?php echo $USER_PROFILE_PANEL_EDITS ? $panel_data['login_gif'] : $USER_PROFILE_PANEL_LOGIN_GIF; ?>);
            height: 100vh;
            background-size: cover;
            background-position: center;
        }
    </style>

</body>

</html>