<?php
/*
 * @ https://hospedagem.matrixch.store 
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 17/06/2024
*/

echo "\r\n      </div>\r\n    </div>\r\n    <!-- /#page-content-wrapper -->\r\n\r\n  </div>\r\n  <!-- /#wrapper -->\r\n\r\n<script src=\"https://code.jquery.com/jquery-3.4.1.js\"></script>\r\n<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js\" integrity=\"sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49\" crossorigin=\"anonymous\"></script>\r\n<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js\" integrity=\"sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy\" crossorigin=\"anonymous\"></script>\r\n<script src=\"https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js\"></script>\r\n<script src=\"https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js\"></script>\r\n<script src=\"js/particles.js\"></script>\r\n<script src=\"js/alerts.js\"></script>\r\n</body>\r\n\r\n</html>\r\n\r\n<script type=\"text/javascript\">\r\n\r\n\r\n//table\r\n\$(document).ready( function () {\r\n    \$('#Dtable').DataTable \r\n                ({\r\n                    \"lengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],\r\n\t\t\t\t\t\"filter\": true,\r\n                    \"Paginate\": true,\r\n\t\t\t\t\t\"ordering\": false,\r\n                });\r\n} );\r\n\r\n\r\n\$(\"#menu-toggle\").click(function(e) {\r\n  e.preventDefault();\r\n  \$(\"#wrapper\").toggleClass(\"toggled\");\r\n});\r\n\r\n//updtae alert\r\n\$(\"#success-alert\").fadeTo(2000, 500).slideUp(500, function(){\r\n    \$(\"#success-alert\").alert('close');\r\n});\r\n\r\n\r\n//delete modal\r\n    \$('#confirm-delete').on('show.bs.modal', function(e) {\r\n        \$(this).find('.btn-ok').attr('href', \$(e.relatedTarget).data('href'));\r\n    });\r\n\r\n</script>\r\n\r\n";
$success = "createAlert('','Success!','Contents were successfully updated','success',true,true,'pageMessages');";
$danger = "createAlert('','Deleted!','Contents were successfully deleted','danger',true,true,'pageMessages');";
$info = "createAlert('','General Alert','Welcome.','info',true,true,'pageMessages');";
$warning = "createAlert('','Warning!','Must fill out all inputs blocks!.','warning',true,true,'pageMessages');";
if (isset($_GET["status"])) {
    if ($_GET["status"] == "1") {
        echo "<script>" . $success . "</script>";
    } else {
        if ($_GET["status"] == "2") {
            echo "<script>" . $danger . "</script>";
        } else {
            if ($_GET["status"] == "3") {
                echo "<script>" . $info . "</script>";
            } else {
                if ($_GET["status"] == "4") {
                    echo "<script>" . $warning . "</script>";
                }
            }
        }
    }
}

?>