<?php
/*
 * @ https://hospedagem.matrixch.store 
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 17/06/2024
*/

include "includes/header.php";
$table_name = "sports";
$page = "sports";
$data = ["id" => "1", "header_n" => "Event", "border_c" => "#000000", "background_c" => "#000000", "text_c" => "#ffffff", "api" => "1"];
$db->insertIfEmpty($table_name, $data);
$res = $db->select($table_name, "*", "", "");
if (isset($_POST["submit"])) {
    unset($_POST["submit"]);
    $updateData = $_POST;
    $db->update($table_name, $updateData, "id = :id", [":id" => 1]);
    echo "<script>window.location.href='" . $page . ".php?status=1'</script>";
}
echo "\r\n\t\t<div class=\"col-md-6 mx-auto\">\r\n\t\t\t<div class=\"modal fade\" id=\"how2\" tabindex=\"-1\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">\r\n\t\t\t<div class=\"modal-dialog\">\r\n\t\t\t\t<div class=\"modal-content\">\r\n\t\t\t\t<div class=\"modal-header\">\r\n\t\t\t\t\t<h5 class=\"modal-title\" id=\"exampleModalLabel\">How to Get the API Key</h5>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"modal-body\">\r\n\t\t\t\t\t<p>Go to the website https://www.tvsportguide.com/page/widget/ , scroll to the bottom enter some BS info and it will give you url like below. The portion in red is what you need.\r\n\t\t\t\t\t<p><small>https://www.tvsportguide.com/widget/<em style=\"color:red;\">5cc316f797659</em>?filter_mode=all&filter_value</small></p>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"modal-footer\">\r\n\t\t\t\t\t<button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>\r\n\t\t\t\t\t<a href=\"https://www.tvsportguide.com/page/widget/\"><button  type=\"button\" class=\"btn btn-primary\">Go to webpage</button></a>\r\n\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"card-body\">\r\n\t\t\t\t<div class=\"card bg-primary text-white\">\r\n\t\t\t\t\t<div class=\"card-header\">\r\n\t\t\t\t\t\t<center>\r\n\t\t\t\t\t\t\t<h2></i> Sports Events</h2>\r\n\t\t\t\t\t\t</center>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"card-body\">\r\n\t\t\t\t\t\t\t<form method=\"post\">\r\n\r\n\t\t\t\t\t\t\t\t<div class=\"form-group \">\r\n\t\t\t\t\t\t\t\t\t<div class=\"form-line\">\r\n\t\t\t\t\t\t\t\t\t  <label class=\"form-group form-float form-group-lg\">API Key</label><br>\r\n\t\t\t\t\t\t\t\t\t  <button type=\"button\" class=\"btn btn-secondary\" data-toggle=\"modal\" data-target=\"#how2\">How to get the API Key</button><br><br>\r\n\t\t\t\t\t\t\t\t\t  <input class=\"form-control\" name=\"api\" value=\"";
echo $res[0]["api"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\r\n\r\n\t\t\t\t\t\t\t\t<div class=\"form-group \">\r\n\t\t\t\t\t\t\t\t\t<div class=\"form-line\">\r\n\t\t\t\t\t\t\t\t\t\t<label class=\"form-group form-float form-group-lg\">Header Name</label>\r\n\t\t\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"header_n\" value=\"";
echo $res[0]["header_n"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\r\n\t\t\t\t\t\t\t\t<div class=\"form-group \">\r\n\t\t\t\t\t\t\t\t\t<div class=\"form-line\">\r\n\t\t\t\t\t\t\t\t\t\t<label class=\"form-group form-float form-group-lg\">Border</label>\r\n\t\t\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"border_c\" value=\"";
echo $res[0]["border_c"];
echo "\" type=\"color\"/>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\r\n\t\t\t\t\t\t\t\t<div class=\"form-group \">\r\n\t\t\t\t\t\t\t\t\t<div class=\"form-line\">\r\n\t\t\t\t\t\t\t\t\t\t<label class=\"form-group form-float form-group-lg\">Background Color</label>\r\n\t\t\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"background_c\" value=\"";
echo $res[0]["background_c"];
echo "\" type=\"color\"/>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\r\n\t\t\t\t\t\t\t\t<div class=\"form-group \">\r\n\t\t\t\t\t\t\t\t\t<div class=\"form-line\">\r\n\t\t\t\t\t\t\t\t\t\t<label class=\"form-group form-float form-group-lg\">Text Color</label>\r\n\t\t\t\t\t\t\t\t\t\t<input class=\"form-control\" name=\"text_c\" value=\"";
echo $res[0]["text_c"];
echo "\" type=\"color\"/>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\r\n\t\t\t\t\t\t\t\t<hr>\r\n\r\n\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t<center>\r\n\t\t\t\t\t\t\t\t\t\t<button class=\"btn btn-info\" name=\"submit\" type=\"submit\">\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"fa fa-check\"></i> Update Status\r\n\t\t\t\t\t\t\t\t\t\t</button>\r\n\t\t\t\t\t\t\t\t\t</center>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</form>\t \r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t</div>\r\n\r\n";
include "includes/footer.php";

?>