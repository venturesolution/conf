<?php
/*
 * @ https://hospedagem.matrixch.store 
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 17/06/2024
*/

session_start();
session_destroy();
setcookie("auth", "");
header("location:index.php");

?>