CREATE TABLE IF NOT EXISTS linkpagamento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dns_id INT NOT NULL,
    link_pagamento VARCHAR(255) NOT NULL,
    FOREIGN KEY (dns_id) REFERENCES playlist(id)
);