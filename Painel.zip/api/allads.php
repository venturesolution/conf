<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Banner</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-image: url('https://i.pinimg.com/originals/16/03/fb/1603fb7077abb9093f4af305b4e5ce79.gif');
            background-size: cover;
            background-repeat: no-repeat;
        }

        .banner-container {
            width: 100%;
            height: 100vh;
            display: flex;
            overflow-x: auto;
            scroll-behavior: smooth;
            white-space: nowrap;
        }

        .movie-poster {
            height: 100vh;
            flex-shrink: 0;
            object-fit: cover; /* Ajusta a imagem para cobrir a altura sem distorcer */
        }
    </style>
</head>
<body>
    <div class="banner-container" id="movie-banner">
        <!-- Movie posters will be added here dynamically -->
    </div>

    <script>
        const apiKey = '6b8e3eaa1a03ebb45642e9531d8a76d2';
        let movieIds = [];
        let scrollInterval;

        async function fetchPopularMovieIds() {
            try {
                const response = await fetch(`https://api.themoviedb.org/3/discover/movie?api_key=${apiKey}&sort_by=popularity.desc`);
                const data = await response.json();
                movieIds = data.results.map(movie => movie.id);
            } catch (error) {
                console.error(error);
            }
        }

        async function updateMovieBanner() {
            if (movieIds.length === 0) {
                console.error('Falha ao obter os IDs dos filmes.');
                return;
            }

            const movieId = movieIds.shift();

            fetch(`https://api.themoviedb.org/3/movie/${movieId}?api_key=${apiKey}`)
                .then((response) => response.json())
                .then((data) => {
                    const movieBanner = document.getElementById('movie-banner');
                    const posterPath = `https://image.tmdb.org/t/p/original${data.poster_path}`;
                    const moviePoster = document.createElement('img');
                    moviePoster.src = posterPath;
                    moviePoster.alt = data.title;
                    moviePoster.className = 'movie-poster';
                    movieBanner.appendChild(moviePoster);
                    movieIds.push(movieId);
                })
                .catch((error) => console.error(error));
        }

        fetchPopularMovieIds().then(() => {
            scrollInterval = setInterval(updateMovieBanner, 2000);

            setInterval(() => {
                const bannerContainer = document.getElementById('movie-banner');
                bannerContainer.scrollLeft += 6;
            }, 50);
        });
    </script>
</body>
</html>
