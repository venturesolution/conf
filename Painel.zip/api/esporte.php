
<!DOCTYPE html>
<html>
<head>
    <title>Esportes</title>
</head>
<body>

<!-- Seu código JavaScript -->
<script src="https://webmasters.onlinebettingacademy.com/assets/js/webmasters.js" data-competition_id="26" data-lang="br" data-timezone="America/Sao_Paulo" data-num_prev="0" data-num_next="10" data-feature_lastm="0" data-feature_match="1" data-widget="comp_matches" data-color="3b5998|8b9dc3|dfe3ee|f7f7f7|ffffff|333333|5f7ec1|263961|d0d0d0|7b7b7b" type="text/javascript"></script>

<script src="https://webmasters.onlinebettingacademy.com/assets/js/webmasters.js" data-competition_id="241" data-lang="br" data-timezone="America/Sao_Paulo" data-num_prev="0" data-num_next="10" data-feature_lastm="0" data-feature_match="1" data-widget="comp_matches" data-color="3b5998|8b9dc3|dfe3ee|f7f7f7|ffffff|333333|5f7ec1|263961|d0d0d0|7b7b7b" type="text/javascript"></script>

<script src="https://webmasters.onlinebettingacademy.com/assets/js/webmasters.js" data-competition_id="297" data-lang="br" data-timezone="America/Sao_Paulo" data-num_prev="0" data-num_next="10" data-feature_lastm="0" data-feature_match="1" data-widget="comp_matches" data-color="3b5998|8b9dc3|dfe3ee|f7f7f7|ffffff|333333|5f7ec1|263961|d0d0d0|7b7b7b" type="text/javascript"></script>

<script src="https://webmasters.onlinebettingacademy.com/assets/js/webmasters.js" data-competition_id="231" data-title="Copa do Brasil" data-lang="br" data-timezone="America/Sao_Paulo" data-num_prev="0" data-num_next="10" data-feature_lastm="0" data-feature_match="1" data-widget="comp_matches" data-color="B2120B|D74F47|D1AEAE|FFF2F2|ffffff|333333|952722|190706|d4a8a6|7b6b6a" type="text/javascript"></script>


</body>
</html>
