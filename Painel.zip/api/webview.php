<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Banner</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-image: url('https://i.imgur.com/AtAk2kr.jpeg'); /* Imagem de fundo mais leve */
            background-size: cover;
            background-repeat: no-repeat;
            font-family: Arial, sans-serif;
        }

        .header-title {
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 2.5rem; /* Tamanho da fonte */
            color: #ffffff;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.7);
            z-index: 10;
        }

        .banner-container {
            width: 100%;
            height: calc(100vh - 70px); /* Ajustado para deixar espaço para o título */
            display: flex;
            overflow-x: auto;
            scroll-behavior: smooth;
            white-space: nowrap;
            padding: 10px;
            box-sizing: border-box;
            margin-top: 70px; /* Espaço para a frase "🎬 Lançamentos" não se sobrepor */
        }

        .movie-poster {
            height: 70vh; /* Diminuindo a altura das capas */
            flex-shrink: 0;
            object-fit: cover;
            border-radius: 20px;
            margin: 0 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            border: 2px solid rgba(255, 255, 255, 0.3); /* Borda branca suave */
        }
    </style>
</head>
<body>
    <div class="header-title">🍿 Lançamentos</div>

    <div class="banner-container" id="movie-banner">
        <!-- Movie posters will be added here dynamically -->
    </div>

    <script>
        const apiKey = '6b8e3eaa1a03ebb45642e9531d8a76d2';
        let movieIds = [];
        let scrollInterval;

        async function fetchPopularMovieIds() {
            try {
                const response = await fetch(`https://api.themoviedb.org/3/discover/movie?api_key=${apiKey}&sort_by=popularity.desc`);
                const data = await response.json();
                movieIds = data.results.map(movie => movie.id);
            } catch (error) {
                console.error(error);
            }
        }

        // Função para carregar múltiplos filmes de uma vez
        async function loadMoviePosters() {
            if (movieIds.length === 0) {
                console.error('Falha ao obter os IDs dos filmes.');
                return;
            }

            const moviePromises = [];
            
            // Carrega 5 filmes por vez
            for (let i = 0; i < 5; i++) {
                const movieId = movieIds.shift();
                const moviePromise = fetch(`https://api.themoviedb.org/3/movie/${movieId}?api_key=${apiKey}`)
                    .then((response) => response.json())
                    .then((data) => {
                        const movieBanner = document.getElementById('movie-banner');
                        const posterPath = `https://image.tmdb.org/t/p/original${data.poster_path}`;
                        const moviePoster = document.createElement('img');
                        moviePoster.src = posterPath;
                        moviePoster.alt = data.title;
                        moviePoster.className = 'movie-poster';
                        movieBanner.appendChild(moviePoster);
                    })
                    .catch((error) => console.error(error));
                
                moviePromises.push(moviePromise);
            }

            // Espera todas as promessas de filmes terminarem
            await Promise.all(moviePromises);
        }

        fetchPopularMovieIds().then(() => {
            // A velocidade foi reduzida para 1 pixel a cada 50ms
            scrollInterval = setInterval(loadMoviePosters, 1000);

            setInterval(() => {
                const bannerContainer = document.getElementById('movie-banner');
                bannerContainer.scrollLeft += 1; // Movendo mais lentamente (menor valor)
            }, 50); // Maior intervalo (50ms) entre os movimentos
        });
    </script>
</body>
</html>
