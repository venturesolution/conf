<?php
/*
 * @ https://hospedagem.matrixch.store 
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 17/06/2024
*/

header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.

include "includes/header.php";
$table_name = "ads";
$base_file = basename($_SERVER["SCRIPT_NAME"]);
$adb->exec("CREATE TABLE IF NOT EXISTS " . $table_name . "(id INTEGER PRIMARY KEY\tAUTOINCREMENT  NOT NULL, title VARCHAR(100), url TEXT)");
$res = $adb->query("SELECT * FROM " . $table_name);
$resU = @$adb->query("SELECT * FROM " . $table_name . " WHERE id='" . $_GET["update"] . "'");
$rowU = @$resU->fetchArray();
if (isset($_POST["submitU"])) {
    $adb->exec("UPDATE " . $table_name . " SET title='" . $_POST["title"] . "',url='" . $_POST["url"] . "' WHERE  id='" . $_POST["id"] . "'");
    $adb->close();
    echo "<script>window.location.href='ads.php';</script>";
    exit;
}
if (isset($_POST["submit"])) {
    $adb->exec("INSERT INTO " . $table_name . "(title, url) VALUES('" . $_POST["title"] . "', '" . $_POST["url"] . "')");
    echo "<script>window.location.href='ads.php';</script>";
    exit;
}
if (isset($_GET["delete"])) {
    $adb->exec("DELETE FROM " . $table_name . " WHERE id=" . $_GET["delete"]);
    echo "<script>window.location.href='ads.php';</script>";
    exit;
}
echo "<div class=\"modal fade\" id=\"confirm-delete\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">\n\t<div class=\"modal-dialog\">\n\t\t<div class=\"modal-content\" style=\"background-color: black;\">\n\t\t\t<div class=\"modal-header\">\n\t\t\t\t<h2 style=\"color: white;\">Confirm</h2>\n\t\t\t</div>\n\t\t\t<div class=\"modal-body\" style=\"color: white;\">\n\t\t\t\tVocê realmente deseja excluir?\n\t\t\t</div>\n\t\t\t<div class=\"modal-footer\">\n\t\t\t\t<button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\">Cancel</button>\n\t\t\t\t<a style=\"color: white;\" class=\"btn btn-danger btn-ok\">Delete</a>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n";
if (isset($_GET["create"])) {
    echo "            <div class=\"col-md-8 mx-auto\">\n                <center>\n\t\t        <h1 class=\"colorboard\"></i>Banners</h1>\n\t            </center>\n\t\t\t\t<div class=\"card bg-primary text-white\">\n\t\t\t\t\t<div class=\"card-header\">\n\t\t\t\t\t\t<center>\n\t\t\t\t\t\t\t<h2><i class=\"fa fa-eye\"></i> Adicionar anúncios</h2>\n\t\t\t\t\t\t</center>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"card-body\">\n        \t\t\t\t<form method=\"post\">\n                            <div class=\"form-group\">\n                              <input class=\"form-control\" type=\"text\" name=\"title\">\n                              <label>Nome</label>\n                            </div>\n                            <div class=\"form-group\">\n                              <input class=\"form-control\" type=\"text\" name=\"url\">\n                              <label>Ad Url ( GIF,PNG,JPG,SVG )</label>\n                            </div>  \n                            <div class=\"col-12\"> <button type=\"submit\" name=\"submit\" class=\"btn btn-info \">Enviar</button> </div>\n                          </form>\n\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\n";
} else {
    if (isset($_GET["update"])) {
        echo "            <div class=\"col-md-8 mx-auto\">\n                <center>\n\t\t        <h1 class=\"colorboard\"></i>Editar Anúncios</h1>\n\t            </center>\n\t\t\t\t<div class=\"card bg-primary text-white\">\n\t\t\t\t\t<div class=\"card-header\">\n\t\t\t\t\t\t<center>\n\t\t\t\t\t\t\t<h2><i class=\"fa fa-file-image-o\"></i> Editar Ad</h2>\n\t\t\t\t\t\t</center>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"card-body\">\n                            <form method=\"post\">\n                                  <input type=\"hidden\" class=\"form-control\" name=\"id\" value=\"";
        echo $_GET["update"];
        echo "\">\n                                <div class=\"user-box\">\n                                  <input type=\"text\" name=\"title\" class=\"form-control\" value=\"";
        echo $rowU["title"];
        echo "\">\n                                  <label>Titulo</label>\n                                </div>\n                                <div class=\"user-box\">\n                                  <input type=\"text\" class=\"form-control\" name=\"url\" value=\"";
        echo $rowU["url"];
        echo "\">\n                                  <label>URL IMAGE ( GIF,PNG,JPG,SVG )</label>\n                                </div>  \n                                <div class=\"col-12\"> <button type=\"submit\" name=\"submitU\" class=\"btn btn-info \">Enviar</button> </div>\n                              </form>\n\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n";
    } else {
        echo "\n\t<div class=\"col-md-12 mx-auto\">\n\t<center>\n\t\t<h1 class=\"colorboard\"></i> Anúncios</h1>\n\t\t<a id=\"button\" href=\"./";
        echo $base_file;
        echo "?create\" class=\"btn btn-primary\">Adicionar</a>\n\t</center>\n\t<br>\n\t<div class=\"table-responsive\">\n\t\t<table class=\"table table-striped table-sm\">\n\t\t\t<thead style=\"color:white!important\">\n\t\t\t\t<tr>\n\t\t\t\t\t<th>Index</th>\n\t\t\t\t\t<th>Title</th>\n\t\t\t\t\t<th>Ad Url</th>\n\t\t\t\t\t<th>Preview</th>\n\t\t\t\t\t<th>Edit&nbsp;&nbsp;&nbsp;Delete</th>\n\t\t\t\t</tr>\n\t\t\t</thead>\n\t\t\t";
        while ($row = $res->fetchArray()) {
            echo "\t\t\t<tbody>\n\t\t\t\t<tr>\n\t\t\t\t\t<td>";
            echo $row["id"];
            echo "</td>\n\t\t\t\t\t<td ";
            if (strpos($row["url"], ".mp4") !== false || strpos($row["url"], ".webm") !== false || strpos($row["url"], ".gif") !== false || strpos($row["url"], ".ogg") !== false) {
                echo "style=\"color: red;\"";
            }
            echo ">";
            echo $row["title"];
            echo "</a></td>\n\t\t\t\t\t<td>";
            echo $row["url"];
            echo "</td>\n\t\t\t\t\t<td>\n\t\t\t\t\t\t";
            if (strpos($row["url"], ".mp4") !== false || strpos($row["url"], ".webm") !== false || strpos($row["url"], ".ogg") !== false) {
                echo "\t\t\t\t\t\t\t<video src=\"";
                echo $row["url"];
                echo "\" controls width=\"100px\" autoplay = true controls = false muted = true loop = false></video>\n\t\t\t\t\t\t";
            } else {
                if (strpos($row["url"], ".jpg") !== false || strpos($row["url"], ".jpeg") !== false || strpos($row["url"], ".png") !== false || strpos($row["url"], ".gif") !== false) {
                    echo "\t\t\t\t\t\t\t<img src=\"";
                    echo $row["url"];
                    echo "\" width=\"100px\"/>\n\t\t\t\t\t\t";
                }
            }
            echo "\t\t\t\t\t</td>\n\t\t\t\t\t<td>\n\t\t\t\t\t\t<a class=\"btn btn-info btn-ok\" href=\"";
            echo $base_file;
            echo "?update=";
            echo $row["id"];
            echo "\"><i class=\"fa fa-pencil-square-o\"></i></a>\n\t\t\t\t\t\t&nbsp;&nbsp;&nbsp;\n\t\t\t\t\t\t<a class=\"btn btn-danger btn-ok\" href=\"#\" data-href=\"";
            echo $base_file;
            echo "?delete=";
            echo $row["id"];
            echo "\" data-toggle=\"modal\" data-target=\"#confirm-delete\"><i class=\"fa fa-trash-o\"></i></a>\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t</tbody>\n\t\t\t";
        }
        echo "\t\t</table>\n\t</div>\n</div>\n\n";
    }
}
echo "\n";
include "includes/footer.php";
echo "<script type=\"text/javascript\">\n//updtae alert\n\$(\"#success-alert\").fadeTo(2000, 500).slideUp(500, function(){\n    \$(\"#success-alert\").alert('close');\n});\n\n\n//delete modal\n    \$('#confirm-delete').on('show.bs.modal', function(e) {\n        \$(this).find('.btn-ok').attr('href', \$(e.relatedTarget).data('href'));\n    });\n\n</script>\n</body>\n</html>";

?>