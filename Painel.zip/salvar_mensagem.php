<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'mensagem' => $_POST['mensagem'],
        'cor' => $_POST['cor'],
        'bgcolor' => $_POST['bgcolor'],
        'opacity' => $_POST['opacity'],
        'fontSize' => $_POST['fontSize'] // Certifique-se de que est�� salvando o tamanho da fonte
    ];

    file_put_contents('mensagem.txt', json_encode($data));
}

header('Location: edit_texto.php');
exit;
