<?php
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.
include "includes/header.php";
?>
<style>
  .custom-button {
    padding: 10px 20px;
  }
    #url-form {
        display: none;
    }
    .custom-input {
        color: blue;
    }

</style>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-1 text-gray-800"> QR Code</h1>
    <!-- Custom codes -->
    <div class="card border-left-primary shadow h-100 card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-cogs"></i> Escolha</h6>
          
        </div>
        <div class="card-body"><center>
                    <h5>Você pode gerar um QR Code para o WhatsApp ou carregar uma imagem</h5></center>
                <br><br>
            <p>Atual</p>
            <img  width="200px" src="api/qr/qr.png">
            <br>
          
           <?php
// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica se foi enviada uma imagem
    if (isset($_FILES["image"])) {
        // Verifica se a imagem é PNG
        $fileType = $_FILES["image"]["type"];
        if ($fileType === "image/png") {
            // Define o caminho para salvar a imagem
            $uploadPath = './api/qr/';
            $fileName = 'qr.png'; // Nome predefinido
            
            // Move a imagem para o diretório de destino
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadPath . $fileName)) {
                echo "Imagem enviada com sucesso.";
            } else {
                echo "Falha ao enviar a imagem.";
            }
        } else {
            echo "Apenas arquivos PNG são permitidos.";
        }
    } else {
        echo "Nenhuma imagem foi enviada.";
    }
}
?>
<!DOCTYPE html>

<body>

    <div>
        <br>
         <br>
    <h5>Gerar</h5>
        <form action="gerarqrcode.php" method="post">

        <label for="url">Insira o número de celular (Ex. 12996200241)</label><br>
        <input type="text" id="url" name="url"> 
        <input type="submit" class='btn btn-success'   value="Gerar QR Code">
    </form>
</body>
    </div>
        <div>
    <br>
    <h5>Carregar Imagem</h5>
    <form method="post" enctype="multipart/form-data">
        <label for="image">(apenas PNG):</label>
        <input type="file" name="image" id="image" accept="image/png">
        <button type="submit" class='btn btn-success'>Enviar</button>
    </form>
    <br>
    </div>
        </div>
</div>
</div>
<?php
include "includes/footer.php";
?>
</body>
</html>
