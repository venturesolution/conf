<?php
/*
 * @ https://hospedagem.matrixch.store 
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 17/06/2024
*/

if (isset($_POST["adType"])) {
    $jsonFilePath = "includes/ad_type.json";
    $jsonData = json_decode(file_get_contents($jsonFilePath), true);
    $jsonData["adType"] = $_POST["adType"];
    file_put_contents($jsonFilePath, json_encode($jsonData));
}

?>