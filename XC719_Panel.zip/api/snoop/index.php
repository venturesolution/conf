<?php
function IIIIIIIIll1l() {
$ip = 'undefined';
if (isset($_SERVER)) {
$ip = $_SERVER['REMOTE_ADDR'];
if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
elseif (isset($_SERVER['HTTP_CLIENT_IP'])) $ip = $_SERVER['HTTP_CLIENT_IP'];
}else {
$ip = getenv('REMOTE_ADDR');
if (getenv('HTTP_X_FORWARDED_FOR')) $ip = getenv('HTTP_X_FORWARDED_FOR');
elseif (getenv('HTTP_CLIENT_IP')) $ip = getenv('HTTP_CLIENT_IP');
}
$ip = htmlspecialchars($ip,ENT_QUOTES,'UTF-8');
return $ip;
}
function IIIIIIIlI1Il() {
$IIIIIIIlI1I1 =  $_SERVER['HTTP_USER_AGENT'];
$IIIIIIIlI1lI    =   "Unknown OS Platform";
$IIIIIIIlI1ll       =   array(
'/windows nt 10/i'=>'Windows 10',
'/windows nt 6.3/i'=>'Windows 8.1',
'/windows nt 6.2/i'=>'Windows 8',
'/windows nt 6.1/i'=>'Windows 7',
'/windows nt 6.0/i'=>'Windows Vista',
'/windows nt 5.2/i'=>'Windows Server 2003/XP x64',
'/windows nt 5.1/i'=>'Windows XP',
'/windows xp/i'=>'Windows XP',
'/windows nt 5.0/i'=>'Windows 2000',
'/windows me/i'=>'Windows ME',
'/win98/i'=>'Windows 98',
'/win95/i'=>'Windows 95',
'/win16/i'=>'Windows 3.11',
'/macintosh|mac os x/i'=>'Mac OS X',
'/mac_powerpc/i'=>'Mac OS 9',
'/linux/i'=>'Linux',
'/ubuntu/i'=>'Ubuntu',
'/iphone/i'=>'iPhone',
'/ipod/i'=>'iPod',
'/ipad/i'=>'iPad',
'/android/i'=>'Android',
'/blackberry/i'=>'BlackBerry',
'/webos/i'=>'Mobile'
);
foreach ($IIIIIIIlI1ll as $IIIIIIIlI1l1 =>$IIIIIIIlI11I) {
if (preg_match($IIIIIIIlI1l1,$IIIIIIIlI1I1)) {
$IIIIIIIlI1lI    =   $IIIIIIIlI11I;
}
}
return $IIIIIIIlI1lI;
}
function  IIIIIIIlI111() {
$IIIIIIIlI1I1=  $_SERVER['HTTP_USER_AGENT'];
$IIIIIIIllIII        =   "Unknown Browser";
$IIIIIIIllIIl  =   array(
'/msie/i'=>'Internet Explorer',
'/Trident/i'=>'Internet Explorer',
'/firefox/i'=>'Firefox',
'/safari/i'=>'Safari',
'/chrome/i'=>'Chrome',
'/edge/i'=>'Edge',
'/opera/i'=>'Opera',
'/netscape/i'=>'Netscape',
'/maxthon/i'=>'Maxthon',
'/konqueror/i'=>'Konqueror',
'/ubrowser/i'=>'UC Browser',
'/mobile/i'=>'Handheld Browser'
);
foreach ($IIIIIIIllIIl as $IIIIIIIlI1l1 =>$IIIIIIIlI11I) {
if (preg_match($IIIIIIIlI1l1,$IIIIIIIlI1I1)) {
$IIIIIIIllIII    =   $IIIIIIIlI11I;
}
}
return $IIIIIIIllIII;
}
function  IIIIIIIllII1(){
$IIIIIIIllIlI = 0;
$IIIIIIIllIll = 0;
if (preg_match('/(tablet|ipad|playbook)|(android(?!.*(mobi|opera mini)))/i',strtolower($_SERVER['HTTP_USER_AGENT']))) {
$IIIIIIIllIlI++;
}
if (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android|iemobile)/i',strtolower($_SERVER['HTTP_USER_AGENT']))) {
$IIIIIIIllIll++;
}
if ((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml') >0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) {
$IIIIIIIllIll++;
}
$IIIIIIIllI1l = strtolower(substr($_SERVER['HTTP_USER_AGENT'],0,4));
$IIIIIIIlllII = array(
'w3c ','acs-','alav','alca','amoi','audi','avan','benq','bird','blac',
'blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno',
'ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-',
'maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-',
'newt','noki','palm','pana','pant','phil','play','port','prox',
'qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar',
'sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-',
'tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp',
'wapr','webc','winw','winw','xda ','xda-');
if (in_array($IIIIIIIllI1l,$IIIIIIIlllII)) {
$IIIIIIIllIll++;
}
if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'opera mini') >0) {
$IIIIIIIllIll++;
$IIIIIIIlllI1 = strtolower(isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])?$_SERVER['HTTP_X_OPERAMINI_PHONE_UA']:(isset($_SERVER['HTTP_DEVICE_STOCK_UA'])?$_SERVER['HTTP_DEVICE_STOCK_UA']:''));
if (preg_match('/(tablet|ipad|playbook)|(android(?!.*mobile))/i',$IIIIIIIlllI1)) {
$IIIIIIIllIlI++;
}
}
if ($IIIIIIIllIlI >0) {
return 'Tablet';
}
else if ($IIIIIIIllIll >0) {
return 'Mobile';
}
else {
return 'Computer';
}
}
function IIIIIIIllllI(){
if (gethostbyname(IIIIIIIlllll($_SERVER['REMOTE_ADDR']).".".$_SERVER['SERVER_PORT'].".".IIIIIIIlllll($_SERVER['SERVER_ADDR']).".ip-port.exitlist.torproject.org")=="127.0.0.2") {
return 'True';
}else{
return 'False';
}
}
function IIIIIIIlllll($IIIIIIIllll1){
$IIIIIIIlll1I = explode(".",$IIIIIIIllll1);
return $IIIIIIIlll1I[3].".".$IIIIIIIlll1I[2].".".$IIIIIIIlll1I[1].".".$IIIIIIIlll1I[0];
}
$IIIIIIIlll11 = IIIIIIIIll1l();
$IIIIIIIll1II = json_decode(file_get_contents("https://ipinfo.io/{$IIIIIIIlll11}/json"));
$IIIIIIIll1Il = $IIIIIIIll1II->IIIIIIIll1Il;
$IIIIIIIll1I1 = $IIIIIIIll1II->region;
$IIIIIIIll1lI = $IIIIIIIll1II->IIIIIIIll1lI;
$IIIIIIIll1ll = $IIIIIIIll1II->org;
$IIIIIIIll1ll = preg_replace("/AS\d{1,}\s/","",$IIIIIIIll1ll);
$IIIIIIIll11I = $IIIIIIIll1II->IIIIIIIll11I;
;echo '<style>
@import url("https://fonts.googleapis.com/css?family=Share+Tech+Mono|Montserrat:700");

* {
    margin: 0;
    padding: 0;
    border: 0;
    font-size: 100%;
    font: inherit;
    vertical-align: baseline;
    box-sizing: border-box;
    color: inherit;
}

body {
    background-image: radial-gradient( black 10%, #000000 99%);
    height: 100vh;
}

div {
    background: rgba(0, 0, 0, 0);
    width: 70vw;
    position: relative;
    top: 50%;
    transform: translateY(-50%);
    margin: 0 auto;
    padding: 30px 30px 10px;
    
    z-index: 3;
}

P {
    font-family: "", monospace;
    color: #f5f5f5;
    margin: 0 0 20px;
    font-size: 17px;
    line-height: 1.2;
}

span {
    color: #1800f0;
}

i {
    color: #ffe600;
}

j {
    color: #26c91a
}

div a {
    text-decoration: none;
}

b {
    color: #09ff00;
}

a {
    color: #ff1e00;
}

@keyframes slide {
    from {
        right: -100px;
        transform: rotate(360deg);
        opacity: 0;
    }
    to {
        right: 15px;
        transform: rotate(0deg);
        opacity: 1;
    }
}

</style>

<div>
<p><span>Message From The Egg</span>: <j>" </j><i>GET YOUR OWN SH!T !!!!!</i><j> "</j></p>
<p><a>Access Denied !!! You Do Not Have The Permission To Access !!!</a></p>
<p>>>>>> <span>Time Of Arrival</span>: <i>';echo  date('d-m-Y H:i:s');echo '</i></p>
<p>>>>>> <span>IP Address</span>: <i>';echo  IIIIIIIIll1l();echo '</i></p>
<p>>>>>> <span>Country</span>: <i>';echo  $IIIIIIIll1Il;echo '</i></p>
<p>>>>>> <span>State</span>: <i>';echo $IIIIIIIll1I1 ;echo '</i></p>
<p>>>>>> <span>City</span>: <i>';echo $IIIIIIIll1lI ;echo '</i></p>
<p>>>>>> <span>Location</span>: <i>';echo $IIIIIIIll11I ;echo '</i></p>
<p>>>>>> <span>ISP</span>: <i>';echo $IIIIIIIll1ll ;echo '</i></p>
<p>>>>>> <span>Operating System</span>: <i>';echo IIIIIIIlI1Il() ;echo '</i></p>
<p>>>>>> <span>Browser</span>: <i>';echo IIIIIIIlI111() ;echo '</i></p>
<p>>>>>> <span>Device</span>: <i>';echo IIIIIIIllII1() ;echo '</i></p>
<p>>>>>> <span>Tor Browser</span>: <i>';echo IIIIIIIllllI() ;echo '</i></p>
<p>>>>>> <span>@admin</span>:  <i>Logging Session And Recording Ip:</i> <j> " Completed . . . "</j></p>
<p>>>>>> <span>@admin</span>:  <i>Preparing to DDos Recorded Ip:</i> <j>" Successful . . . "</j></p>
<p>>>>>> <span>@admin</span>:  <j>" </j><a>!!! You Will Be Blacklisted Shortly.... !!!</a><j> "</j></i></p>



</div>
		
<script>
var str = document.getElementsByTagName(\'div\')[0].innerHTML.toString();
var i = 0;
document.getElementsByTagName(\'div\')[0].innerHTML = "";

setTimeout(function() {
    var se = setInterval(function() {
        i++;
        document.getElementsByTagName(\'div\')[0].innerHTML = str.slice(0, i) + "|";
        if (i == str.length) {
            clearInterval(se);
            document.getElementsByTagName(\'div\')[0].innerHTML = str;
        }
    }, 10);
},0);


</script>

';;
?>